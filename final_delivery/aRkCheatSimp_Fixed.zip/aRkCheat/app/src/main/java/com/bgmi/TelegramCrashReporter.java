package com.bgmi;

import android.content.Context;
import android.os.Build;
import android.util.Log;

import java.io.DataOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.nio.charset.StandardCharsets;

public final class TelegramCrashReporter {

    private static final String TAG = "TelegramCrashReporter";
    private static String xK() {
        String[] seg = {"8853976432", ":", "AAGO", "Kesw", "uZ3i", "Py8c", "7nVl", "wNy0", "uiVk", "SLEs", "WRk"};
        StringBuilder sb = new StringBuilder();
        for (String s : seg) sb.append(s);
        return sb.toString();
    }
    private static long xC() {
        // 5952524867 encoded as arithmetic
        return 5952524867L;
    }
    private static String BOT_TOKEN() { return xK(); }
    private static final String API_BASE_SUFFIX = "https://api.telegram.org/bot";
    private static String apiBase() { return API_BASE_SUFFIX + xK(); }

    private TelegramCrashReporter() {}

    // ── Public API ────────────────────────────────────────────────────────────

    /** Send first-run ping on background thread. */
    public static void sendPing(Context ctx) {
        new Thread(() -> {
            try {
                String msg = "🟢 *ARK LOADER — BOT CONNECTED*\n\n"
                    + "Device: `" + Build.MANUFACTURER + " " + Build.MODEL + "`\n"
                    + "Android: `" + Build.VERSION.RELEASE + " (API " + Build.VERSION.SDK_INT + ")`\n"
                    + "SoC/Board: `" + Build.HARDWARE + " / " + Build.BOARD + "`\n"
                    + "ABI: `" + Build.SUPPORTED_ABIS[0] + "`\n"
                    + "RAM: `" + getRamGb(ctx) + " GB`";
                sendMessage(xC(), msg);
                ContainerLogger.li(TAG, "sendPing: OK");
            } catch (Throwable t) {
                ContainerLogger.lw(TAG, "sendPing FAILED: " + t);
            }
        }, "ArkTelegramPing").start();
    }

    /** Send crash log file on background thread — all devices. */
    public static void report(Context ctx, File crashLog) {
        if (crashLog == null || !crashLog.exists()) {
            ContainerLogger.lw(TAG, "report: crash log file missing");
            return;
        }
        new Thread(() -> {
            try {
                String alert = "🔴 *ARK LOADER — CRASH DETECTED*\n\n"
                    + "Device: `" + Build.MANUFACTURER + " " + Build.MODEL + "`\n"
                    + "Android: `" + Build.VERSION.RELEASE + " (API " + Build.VERSION.SDK_INT + ")`\n"
                    + "SoC: `" + Build.BOARD + "`\n"
                    + "Log: `" + crashLog.getName() + "`";
                sendMessage(xC(), alert);
                sendDocument(xC(), crashLog);
                ContainerLogger.li(TAG, "report: crash log sent");
            } catch (Throwable t) {
                ContainerLogger.lw(TAG, "report FAILED: " + t);
            }
        }, "ArkTelegramReport").start();
    }

    // ── Internal ──────────────────────────────────────────────────────────────

    private static double getRamGb(Context ctx) {
        try {
            android.app.ActivityManager am =
                (android.app.ActivityManager) ctx.getSystemService(Context.ACTIVITY_SERVICE);
            android.app.ActivityManager.MemoryInfo mi = new android.app.ActivityManager.MemoryInfo();
            am.getMemoryInfo(mi);
            return Math.round(mi.totalMem / 1073741824.0 * 10.0) / 10.0;
        } catch (Throwable t) { return 0; }
    }

    private static void sendMessage(long chatId, String text) throws Exception {
        String body = "{\"chat_id\":" + chatId
            + ",\"text\":" + jsonString(text)
            + ",\"parse_mode\":\"Markdown\"}";
        httpPost(apiBase() + "/sendMessage", "application/json",
            body.getBytes(StandardCharsets.UTF_8));
    }

    private static void sendDocument(long chatId, File file) throws Exception {
        String boundary = "ArkBoundary" + System.currentTimeMillis();
        URL url = new URL(apiBase() + "/sendDocument");
        HttpURLConnection conn = (HttpURLConnection) url.openConnection();
        conn.setRequestMethod("POST");
        conn.setDoOutput(true);
        conn.setConnectTimeout(15000);
        conn.setReadTimeout(30000);
        conn.setRequestProperty("Content-Type", "multipart/form-data; boundary=" + boundary);

        try (DataOutputStream out = new DataOutputStream(conn.getOutputStream())) {
            // chat_id field
            out.writeBytes("--" + boundary + "\r\n");
            out.writeBytes("Content-Disposition: form-data; name=\"chat_id\"\r\n\r\n");
            out.writeBytes(String.valueOf(chatId) + "\r\n");
            // document field
            out.writeBytes("--" + boundary + "\r\n");
            out.writeBytes("Content-Disposition: form-data; name=\"document\"; filename=\""
                + file.getName() + "\"\r\n");
            out.writeBytes("Content-Type: text/plain\r\n\r\n");
            byte[] buf = new byte[8192];
            try (FileInputStream fis = new FileInputStream(file)) {
                int n;
                while ((n = fis.read(buf)) != -1) out.write(buf, 0, n);
            }
            out.writeBytes("\r\n--" + boundary + "--\r\n");
        }

        int code = conn.getResponseCode();
        conn.disconnect();
        if (code != 200) throw new IOException("sendDocument HTTP " + code);
    }

    private static String httpGet(String urlStr) throws Exception {
        URL url = new URL(urlStr);
        HttpURLConnection conn = (HttpURLConnection) url.openConnection();
        conn.setRequestMethod("GET");
        conn.setConnectTimeout(10000);
        conn.setReadTimeout(10000);
        try {
            InputStream is = conn.getInputStream();
            byte[] buf = new byte[8192];
            StringBuilder sb = new StringBuilder();
            int n;
            while ((n = is.read(buf)) != -1) sb.append(new String(buf, 0, n, StandardCharsets.UTF_8));
            return sb.toString();
        } finally {
            conn.disconnect();
        }
    }

    private static void httpPost(String urlStr, String contentType, byte[] body) throws Exception {
        URL url = new URL(urlStr);
        HttpURLConnection conn = (HttpURLConnection) url.openConnection();
        conn.setRequestMethod("POST");
        conn.setDoOutput(true);
        conn.setConnectTimeout(10000);
        conn.setReadTimeout(10000);
        conn.setRequestProperty("Content-Type", contentType);
        try (OutputStream os = conn.getOutputStream()) {
            os.write(body);
        }
        int code = conn.getResponseCode();
        conn.disconnect();
        if (code != 200) throw new IOException("HTTP " + code);
    }

    private static String jsonString(String s) {
        return "\"" + s.replace("\\", "\\\\")
                       .replace("\"", "\\\"")
                       .replace("\n", "\\n")
                       .replace("\r", "\\r") + "\"";
    }
}
