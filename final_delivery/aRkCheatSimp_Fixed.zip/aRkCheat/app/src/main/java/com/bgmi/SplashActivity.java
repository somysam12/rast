package com.bgmi;

import android.animation.Animator;
import android.animation.AnimatorListenerAdapter;
import android.animation.AnimatorSet;
import android.animation.ObjectAnimator;
import android.animation.ValueAnimator;
import android.content.Intent;
import android.graphics.Color;
import android.graphics.drawable.GradientDrawable;
import android.media.MediaPlayer;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.view.Window;
import android.view.WindowManager;
import android.view.animation.AccelerateDecelerateInterpolator;
import android.view.animation.DecelerateInterpolator;
import android.view.animation.OvershootInterpolator;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.RelativeLayout;

import androidx.appcompat.app.AppCompatActivity;

@SuppressWarnings({"unused","deprecation"})
public class SplashActivity extends AppCompatActivity {

    public static boolean launched = false;
    private final Handler handler = new Handler(Looper.getMainLooper());
    private MediaPlayer mpOpen;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        launched = true;

        requestWindowFeature(Window.FEATURE_NO_TITLE);
        getWindow().setFlags(
            WindowManager.LayoutParams.FLAG_FULLSCREEN,
            WindowManager.LayoutParams.FLAG_FULLSCREEN);
        getWindow().addFlags(WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS
            | WindowManager.LayoutParams.FLAG_DRAWS_SYSTEM_BAR_BACKGROUNDS);
        getWindow().setStatusBarColor(Color.TRANSPARENT);
        getWindow().setNavigationBarColor(Color.TRANSPARENT);

        FrameLayout root = buildSplash();
        setContentView(root);

        try {
            mpOpen = MediaPlayer.create(this, R.raw.app_open);
            if (mpOpen != null) mpOpen.start();
        } catch (Exception ignored) {}

        root.post(() -> runAnimation(root));
    }

    private FrameLayout buildSplash() {
        FrameLayout root = new FrameLayout(this);
        root.setBackgroundColor(Color.parseColor("#080400"));

        // Radial glow background — subtle orange center
        View glow = new View(this);
        GradientDrawable glowBg = new GradientDrawable(
            GradientDrawable.Orientation.TOP_BOTTOM,
            new int[]{0x00FF6600, 0x00FF6600});
        // Use radial via setGradientType
        GradientDrawable radial = new GradientDrawable();
        radial.setGradientType(GradientDrawable.RADIAL_GRADIENT);
        radial.setColors(new int[]{0x33FF6600, 0x00000000});
        radial.setGradientRadius(600);
        glow.setBackground(radial);
        glow.setAlpha(0f);
        glow.setTag("glow");
        root.addView(glow, new FrameLayout.LayoutParams(
            FrameLayout.LayoutParams.MATCH_PARENT, FrameLayout.LayoutParams.MATCH_PARENT));

        // Center column
        LinearLayout col = new LinearLayout(this);
        col.setOrientation(LinearLayout.VERTICAL);
        col.setGravity(Gravity.CENTER_HORIZONTAL);
        FrameLayout.LayoutParams colLp = new FrameLayout.LayoutParams(
            FrameLayout.LayoutParams.MATCH_PARENT, FrameLayout.LayoutParams.WRAP_CONTENT);
        colLp.gravity = Gravity.CENTER;
        col.setLayoutParams(colLp);

        // A logo circle
        ImageView logo = new ImageView(this);
        logo.setTag("logo");
        logo.setImageResource(R.drawable.ark_logo_circle);
        logo.setScaleType(ImageView.ScaleType.FIT_CENTER);
        logo.setAlpha(0f);
        logo.setScaleX(0.4f); logo.setScaleY(0.4f);
        LinearLayout.LayoutParams logoLp =
            new LinearLayout.LayoutParams(dp(110), dp(110));
        logoLp.gravity = Gravity.CENTER_HORIZONTAL;
        logoLp.bottomMargin = dp(20);
        logo.setLayoutParams(logoLp);
        col.addView(logo);

        // Flame text "aRkCheat"
        ImageView flameTxt = new ImageView(this);
        flameTxt.setTag("flame");
        flameTxt.setImageResource(R.drawable.ark_flame_text);
        flameTxt.setScaleType(ImageView.ScaleType.FIT_CENTER);
        flameTxt.setAlpha(0f);
        flameTxt.setTranslationY(dp(40));
        LinearLayout.LayoutParams ftLp =
            new LinearLayout.LayoutParams(dp(300), dp(164));
        ftLp.gravity = Gravity.CENTER_HORIZONTAL;
        flameTxt.setLayoutParams(ftLp);
        col.addView(flameTxt);

        root.addView(col);
        return root;
    }

    private void runAnimation(FrameLayout root) {
        View glow  = root.findViewWithTag("glow");
        View logo  = root.findViewWithTag("logo");
        View flame = root.findViewWithTag("flame");

        // 1. Glow fades in
        ObjectAnimator glowA = ObjectAnimator.ofFloat(glow, "alpha", 0f, 1f);
        glowA.setDuration(800);

        // 2. Logo bursts in with overshoot
        ObjectAnimator logoA  = ObjectAnimator.ofFloat(logo, "alpha", 0f, 1f);
        ObjectAnimator logoSx = ObjectAnimator.ofFloat(logo, "scaleX", 0.4f, 1f);
        ObjectAnimator logoSy = ObjectAnimator.ofFloat(logo, "scaleY", 0.4f, 1f);
        logoA.setDuration(700); logoA.setStartDelay(200);
        logoSx.setDuration(700); logoSx.setStartDelay(200);
        logoSy.setDuration(700); logoSy.setStartDelay(200);
        logoSx.setInterpolator(new OvershootInterpolator(2.0f));
        logoSy.setInterpolator(new OvershootInterpolator(2.0f));

        // 3. Logo pulses after appearing
        ObjectAnimator logoPulse = ObjectAnimator.ofFloat(logo, "scaleX", 1f, 1.07f, 1f);
        logoPulse.setDuration(500); logoPulse.setStartDelay(950);
        ObjectAnimator logoPulseY = ObjectAnimator.ofFloat(logo, "scaleY", 1f, 1.07f, 1f);
        logoPulseY.setDuration(500); logoPulseY.setStartDelay(950);

        // 4. Flame text rises up from below
        ObjectAnimator flameA  = ObjectAnimator.ofFloat(flame, "alpha", 0f, 1f);
        ObjectAnimator flameTy = ObjectAnimator.ofFloat(flame, "translationY", dp(40), 0f);
        flameA.setDuration(600); flameA.setStartDelay(600);
        flameTy.setDuration(700); flameTy.setStartDelay(600);
        flameTy.setInterpolator(new DecelerateInterpolator(1.8f));

        AnimatorSet set = new AnimatorSet();
        set.playTogether(glowA, logoA, logoSx, logoSy, logoPulse, logoPulseY, flameA, flameTy);
        set.start();

        // Fade out + go login after 2.4s
        handler.postDelayed(() -> fadeAndGo(root), 2400);
    }

    private void fadeAndGo(View root) {
        if (isFinishing() || isDestroyed()) return;
        ObjectAnimator out = ObjectAnimator.ofFloat(root, "alpha", 1f, 0f);
        out.setDuration(350);
        out.setInterpolator(new AccelerateDecelerateInterpolator());
        out.addListener(new AnimatorListenerAdapter() {
            @Override public void onAnimationEnd(Animator a) { goLogin(); }
        });
        out.start();
    }

    private void goLogin() {
        if (isFinishing() || isDestroyed()) return;
        startActivity(new Intent(this, LoginActivity.class));
        overridePendingTransition(R.anim.slide_up_enter, R.anim.splash_exit);
        finish();
    }

    // ── Static helpers used by LoginActivity ─────────────────────────────────
    public static void playTap(android.content.Context ctx) {
        try {
            MediaPlayer mp = MediaPlayer.create(ctx, R.raw.tap);
            if (mp != null) {
                mp.setVolume(0.7f, 0.7f); mp.start();
                mp.setOnCompletionListener(MediaPlayer::release);
            }
        } catch (Exception ignored) {}
    }

    public static void playLaunch(android.content.Context ctx) {
        try {
            MediaPlayer mp = MediaPlayer.create(ctx, R.raw.launch);
            if (mp != null) {
                mp.setVolume(0.8f, 0.8f); mp.start();
                mp.setOnCompletionListener(MediaPlayer::release);
            }
        } catch (Exception ignored) {}
    }

    private int dp(float v) {
        return (int) android.util.TypedValue.applyDimension(
            android.util.TypedValue.COMPLEX_UNIT_DIP, v, getResources().getDisplayMetrics());
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        handler.removeCallbacksAndMessages(null);
        if (mpOpen != null) { try { mpOpen.release(); } catch (Exception ignored) {} }
    }
}
