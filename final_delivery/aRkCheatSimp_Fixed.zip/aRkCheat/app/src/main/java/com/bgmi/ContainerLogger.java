package com.bgmi;

import android.content.Context;
import android.content.SharedPreferences;
import android.os.Build;
import android.os.Environment;
import android.os.StatFs;
import android.util.DisplayMetrics;
import android.util.Log;
import android.view.WindowManager;

import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.io.PrintWriter;
import java.io.StringWriter;
import java.text.SimpleDateFormat;
import java.util.Arrays;
import java.util.Comparator;
import java.util.Date;
import java.util.Locale;

public final class ContainerLogger {

    private static final String TAG = "ContainerLogger";
    private static final String LOG_DIR = "/storage/emulated/0/ContainerLogs";
    private static final String PREFS = "ark_container_logger";
    private static final String PREF_FIRST_RUN = "first_run";
    private static final String PREF_CRASH_LOG = "last_crash_log";
    private static final int MAX_LOG_FILES = 15;

    private static volatile ContainerLogger sInstance;

    private final File mLogFile;
    private final Context mCtx;
    private volatile boolean mReady = false;

    // ── Factory ───────────────────────────────────────────────────────────────

    public static void init(Context ctx) {
        if (sInstance != null) return;
        synchronized (ContainerLogger.class) {
            if (sInstance != null) return;
            sInstance = new ContainerLogger(ctx.getApplicationContext());
        }
    }

    public static ContainerLogger get() {
        ContainerLogger inst = sInstance;
        if (inst == null) throw new IllegalStateException("ContainerLogger.init() not called");
        return inst;
    }

    // ── Convenience statics ───────────────────────────────────────────────────

    public static void li(String tag, String msg) {
        try { get().log(tag, "I", msg); } catch (Throwable ignored) {}
    }

    public static void ld(String tag, String msg) {
        try { get().log(tag, "D", msg); } catch (Throwable ignored) {}
    }

    public static void lw(String tag, String msg) {
        try { get().log(tag, "W", msg); } catch (Throwable ignored) {}
    }

    public static void le(String tag, String msg) {
        try { get().log(tag, "E", msg); } catch (Throwable ignored) {}
    }

    public static void le(String tag, String msg, Throwable t) {
        try {
            StringWriter sw = new StringWriter();
            t.printStackTrace(new PrintWriter(sw));
            get().log(tag, "E", msg + "\n" + sw);
        } catch (Throwable ignored) {}
    }

    // ── Constructor ───────────────────────────────────────────────────────────

    private ContainerLogger(Context ctx) {
        mCtx = ctx;
        File dir = new File(LOG_DIR);
        try { dir.mkdirs(); } catch (Throwable ignored) {}

        String ts = new SimpleDateFormat("yyyyMMdd-HHmmss", Locale.US).format(new Date());
        String pid = Integer.toHexString(android.os.Process.myPid());
        mLogFile = new File(dir, "session_" + ts + "-" + pid + ".log");

        try {
            writeHeader();
            mReady = true;
            pruneOldLogs(dir);
            installCrashHandler();
        } catch (Throwable t) {
            Log.w(TAG, "ContainerLogger init failed: " + t);
        }
    }

    // ── Public ────────────────────────────────────────────────────────────────

    public File getLogFile() { return mLogFile; }

    public boolean isFirstRun() {
        return mCtx.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
                   .getBoolean(PREF_FIRST_RUN, true);
    }

    public void markFirstRunDone() {
        mCtx.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
            .edit().putBoolean(PREF_FIRST_RUN, false).apply();
    }

    public File getPendingCrashLog() {
        String path = mCtx.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
                          .getString(PREF_CRASH_LOG, null);
        if (path == null) return null;
        File f = new File(path);
        return f.exists() ? f : null;
    }

    public void clearPendingCrashLog() {
        mCtx.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
            .edit().remove(PREF_CRASH_LOG).apply();
    }

    public synchronized void log(String tag, String level, String message) {
        if (!mReady) return;
        String ts = new SimpleDateFormat("MM-dd HH:mm:ss.SSS", Locale.US).format(new Date());
        String line = ts + " [" + tag + "/" + level + "] " + message;
        Log.println(levelToInt(level), TAG, line);
        try (FileWriter fw = new FileWriter(mLogFile, true)) {
            fw.write(line);
            fw.write('\n');
        } catch (IOException ignored) {}
    }

    // ── Private ───────────────────────────────────────────────────────────────

    private void writeHeader() throws IOException {
        String sessionTs = new SimpleDateFormat("yyyyMMdd-HHmmss", Locale.US).format(new Date());
        String startTime = new SimpleDateFormat("MM-dd HH:mm:ss.SSS", Locale.US).format(new Date());
        String pid       = Integer.toHexString(android.os.Process.myPid());

        String model   = Build.MANUFACTURER.toUpperCase(Locale.US) + " " + Build.MODEL;
        String brand   = Build.BRAND + " / " + Build.MANUFACTURER;
        String soc     = Build.HARDWARE + " / " + Build.BOARD;
        int    api     = Build.VERSION.SDK_INT;
        String ver     = "Android " + Build.VERSION.RELEASE + " (API " + api + ")";
        String build   = Build.DISPLAY;
        String abis    = Arrays.toString(Build.SUPPORTED_ABIS);
        int    cores   = Runtime.getRuntime().availableProcessors();

        String screen  = getScreenInfo();
        String ram     = getRamInfo();
        String storage = getStorageInfo();

        StringBuilder sb = new StringBuilder();
        sb.append("======================================================================\n");
        sb.append("  ARK LOADER — SESSION START\n");
        sb.append("======================================================================\n");
        sb.append("Session      : ").append(sessionTs).append("-").append(pid).append("\n");
        sb.append("Start Time   : ").append(startTime).append("\n");
        sb.append("App Version  : ").append(getAppVersion()).append(" (ArkLoader)\n");
        sb.append("Target Game  : com.pubg.imobile\n");
        sb.append("----------------------------------------------------------------------\n");
        sb.append("DEVICE / RUNTIME:\n");
        sb.append("  Model      : ").append(model).append("\n");
        sb.append("  Brand/OEM  : ").append(brand).append("\n");
        sb.append("  SoC/Board  : ").append(soc).append("\n");
        sb.append("  Android OS : ").append(ver).append("\n");
        sb.append("  Build      : ").append(build).append("\n");
        sb.append("  CPU ABIs   : ").append(abis).append(" (").append(cores).append(" cores)\n");
        sb.append("  Screen     : ").append(screen).append("\n");
        sb.append("  RAM        : ").append(ram).append("\n");
        sb.append("  Storage    : ").append(storage).append("\n");
        sb.append("  Log Dir    : ").append(LOG_DIR).append("\n");
        sb.append("======================================================================\n\n");

        try (FileWriter fw = new FileWriter(mLogFile, false)) {
            fw.write(sb.toString());
        }
    }

    private String getAppVersion() {
        try {
            android.content.pm.PackageInfo pi = mCtx.getPackageManager()
                .getPackageInfo(mCtx.getPackageName(), 0);
            return pi.versionName;
        } catch (Throwable t) { return "?"; }
    }

    private String getScreenInfo() {
        try {
            DisplayMetrics dm = new DisplayMetrics();
            WindowManager wm = (WindowManager) mCtx.getSystemService(Context.WINDOW_SERVICE);
            if (wm != null) {
                wm.getDefaultDisplay().getRealMetrics(dm);
                int hz = 60;
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
                    try { hz = (int) wm.getCurrentWindowMetrics().getWindowInsets()
                        .getClass().getMethod("getDisplayCutout").invoke(null); }
                    catch (Throwable ignored) {}
                    try { hz = (int) wm.getDefaultDisplay().getRefreshRate(); }
                    catch (Throwable ignored) {}
                }
                return dm.widthPixels + "x" + dm.heightPixels
                    + " px @ " + dm.densityDpi + " dpi, " + hz + " Hz";
            }
        } catch (Throwable ignored) {}
        return "?";
    }

    private String getRamInfo() {
        try {
            android.app.ActivityManager am =
                (android.app.ActivityManager) mCtx.getSystemService(Context.ACTIVITY_SERVICE);
            android.app.ActivityManager.MemoryInfo mi = new android.app.ActivityManager.MemoryInfo();
            am.getMemoryInfo(mi);
            return String.format(Locale.US, "%.1f GB total / %.1f GB avail",
                mi.totalMem / 1073741824.0, mi.availMem / 1073741824.0);
        } catch (Throwable t) { return "?"; }
    }

    private String getStorageInfo() {
        try {
            StatFs sf = new StatFs(Environment.getExternalStorageDirectory().getPath());
            long total = sf.getTotalBytes();
            long free  = sf.getFreeBytes();
            return String.format(Locale.US, "%.1f GB total / %.1f GB free",
                total / 1073741824.0, free / 1073741824.0);
        } catch (Throwable t) { return "?"; }
    }

    private void pruneOldLogs(File dir) {
        try {
            File[] files = dir.listFiles(f -> f.getName().startsWith("session_") && f.getName().endsWith(".log"));
            if (files == null || files.length <= MAX_LOG_FILES) return;
            Arrays.sort(files, Comparator.comparingLong(File::lastModified));
            int toDelete = files.length - MAX_LOG_FILES;
            for (int i = 0; i < toDelete; i++) {
                files[i].delete();
            }
        } catch (Throwable ignored) {}
    }

    private void installCrashHandler() {
        Thread.UncaughtExceptionHandler existing = Thread.getDefaultUncaughtExceptionHandler();
        Thread.setDefaultUncaughtExceptionHandler((thread, ex) -> {
            try {
                StringWriter sw = new StringWriter();
                ex.printStackTrace(new PrintWriter(sw));
                log("crash", "E", "UNCAUGHT EXCEPTION on thread=" + thread.getName()
                    + "\n" + sw);
                log("crash", "E", "Device=" + Build.MODEL
                    + " API=" + Build.VERSION.SDK_INT
                    + " SoC=" + Build.BOARD);
                // Flush the crash file path for next-launch Telegram report
                mCtx.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
                    .edit().putString(PREF_CRASH_LOG, mLogFile.getAbsolutePath()).apply();
            } catch (Throwable ignored) {}
            if (existing != null) existing.uncaughtException(thread, ex);
        });
    }

    private static int levelToInt(String level) {
        switch (level) {
            case "V": return Log.VERBOSE;
            case "D": return Log.DEBUG;
            case "W": return Log.WARN;
            case "E": return Log.ERROR;
            default:  return Log.INFO;
        }
    }
}
