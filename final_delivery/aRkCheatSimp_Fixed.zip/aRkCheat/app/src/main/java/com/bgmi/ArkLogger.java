package com.bgmi;

import android.os.Environment;
import java.io.File;
import java.io.FileWriter;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Locale;

/**
 * Temporary debug logger — writes to /sdcard/Download/ark.log
 * Remove or disable LOG_ENABLED when done debugging.
 */
public final class ArkLogger {

    private static final boolean LOG_ENABLED = false; // disabled — use ArkCrashLogger
    private static final String  FILE_NAME   = "ark.log";
    private static final String  DATE_FMT    = "MM-dd HH:mm:ss.SSS";

    private ArkLogger() {}

    public static void log(String tag, String msg) {
        if (!LOG_ENABLED) return;
        try {
            File dir = Environment.getExternalStoragePublicDirectory(
                    Environment.DIRECTORY_DOWNLOADS);
            if (dir == null || (!dir.exists() && !dir.mkdirs())) return;

            File f = new File(dir, FILE_NAME);
            String ts   = new SimpleDateFormat(DATE_FMT, Locale.US).format(new Date());
            String line = ts + "  [" + tag + "]  " + msg + "\n";

            FileWriter fw = new FileWriter(f, true /* append */);
            fw.write(line);
            fw.flush();
            fw.close();
        } catch (Throwable ignored) {}
    }

    /** Write a visible section separator */
    public static void section(String title) {
        log("────", "── " + title + " ──");
    }
}
