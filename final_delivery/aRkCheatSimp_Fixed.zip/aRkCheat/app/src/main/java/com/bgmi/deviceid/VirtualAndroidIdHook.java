package com.bgmi.deviceid;

import android.app.Application;
import android.content.Context;
import android.database.Cursor;
import android.database.CursorWrapper;
import android.net.Uri;
import android.os.Bundle;
import android.util.Log;

import com.mundo.MundoCore;
import com.mundo.app.configuration.AppLifecycleCallback;

import java.lang.reflect.Field;
import java.lang.reflect.InvocationHandler;
import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;
import java.lang.reflect.Proxy;
import java.util.Map;

public final class VirtualAndroidIdHook {

    private static final String TAG = "VirtualAndroidIdHook";

    public static final String PREF_FILE        = "ark_device_id_hook";
    public static final String PREF_HOOK_ID     = "hook_id";
    public static final String PREF_HOOK_ACTIVE = "hook_active";

    public enum OverrideState { ACTIVE, PASSTHROUGH }

    public static volatile String sConfirmedId = "";

    private VirtualAndroidIdHook() {}

    // ── Public API ─────────────────────────────────────────────────────────────

    public static void registerEarlyHook(Context appCtx) {
        try {
            VirtualDeviceIdStore store = new VirtualDeviceIdStore(appCtx);
            String id = store.desired();
            if (id.isEmpty()) id = store.change();

            com.bgmi.ArkLogger.log("HOOK", "registerEarlyHook called id=" + id
                + " thread=" + Thread.currentThread().getName());

            setSettingsWrapper(id, OverrideState.ACTIVE);

            com.bgmi.ArkLogger.log("HOOK", "setSettingsWrapper done — IPC hook active");

            try {
                appCtx.getSharedPreferences(PREF_FILE, Context.MODE_PRIVATE)
                      .edit()
                      .putString(PREF_HOOK_ID, id)
                      .putBoolean(PREF_HOOK_ACTIVE, true)
                      .apply();
            } catch (Throwable ignored) {}

            Log.i(TAG, "registerEarlyHook: id=" + id);
            com.bgmi.ArkLogger.section("HOOK INSTALLED");
            com.bgmi.ArkLogger.log("HOOK", "Fake android_id = " + id);
            com.bgmi.ArkLogger.log("HOOK", "Real android_id = " + getRealAndroidId(appCtx));
        } catch (Throwable t) {
            Log.w(TAG, "registerEarlyHook FAILED: " + t);
            com.bgmi.ArkLogger.log("HOOK", "registerEarlyHook FAILED: " + t);
        }
    }

    private static String getRealAndroidId(Context ctx) {
        try {
            return android.provider.Settings.Secure.getString(
                ctx.getContentResolver(), android.provider.Settings.Secure.ANDROID_ID);
        } catch (Throwable t) { return "unavailable"; }
    }

    public static void setupInterceptor(Context appCtx, String fakeId) {
        if (fakeId == null || fakeId.isEmpty()) {
            Log.w(TAG, "setupInterceptor: empty fakeId — skip");
            return;
        }
        try {
            MundoCore.get().addAppLifecycleCallback(new AppLifecycleCallback() {
                @Override
                public void beforeApplicationOnCreate(String packageName, String processName,
                                                      Application application, int userId) {
                    // Log via android.util.Log (works in any process)
                    Log.i(TAG, "beforeAppCreate pkg=" + packageName + " proc=" + processName
                        + " id=" + fakeId);
                    // Also try ArkLogger (works if this runs in host process)
                    try {
                        com.bgmi.ArkLogger.log("HOOK", "beforeAppCreate: pkg=" + packageName
                            + " proc=" + processName + " id=" + fakeId);
                    } catch (Throwable ignored) {}

                    try {
                        installInProcess(fakeId);
                        Log.i(TAG, "beforeAppCreate: installInProcess done id=" + fakeId);
                        try {
                            com.bgmi.ArkLogger.log("HOOK",
                                "installInProcess done — fake id active in proc=" + processName);
                        } catch (Throwable ignored) {}
                    } catch (Throwable t) {
                        Log.w(TAG, "beforeAppCreate: installInProcess FAILED: " + t);
                        try {
                            com.bgmi.ArkLogger.log("HOOK",
                                "installInProcess FAILED proc=" + processName + ": " + t);
                        } catch (Throwable ignored) {}
                    }
                }
            });
            com.bgmi.ArkLogger.log("HOOK", "setupInterceptor: lifecycle callback registered id=" + fakeId);
            Log.i(TAG, "setupInterceptor: registered lifecycle callback id=" + fakeId);
        } catch (Throwable t) {
            Log.w(TAG, "setupInterceptor FAILED: " + t);
            com.bgmi.ArkLogger.log("HOOK", "setupInterceptor FAILED: " + t);
        }
    }

    // ── Internal ───────────────────────────────────────────────────────────────

    @SuppressWarnings("unchecked")
    private static void installInProcess(String fakeId) throws Exception {
        OverrideState state = OverrideState.ACTIVE;

        Class<?> secureClass = Class.forName("android.provider.Settings$Secure");
        Field cacheField = findField(secureClass, "sNameValueCache");
        Object cache = cacheField.get(null);
        if (cache == null) {
            Log.w(TAG, "installInProcess: sNameValueCache is null");
            return;
        }

        // ── Step 1: Pre-fill mValues with fake ID (most reliable path) ─────────
        // NameValueCache checks mValues BEFORE calling IContentProvider.
        // Direct injection here bypasses provider entirely — no race condition.
        try {
            Field mValuesField = findField(cache.getClass(), "mValues");
            synchronized (cache) {
                Map<Object, Object> mValues = (Map<Object, Object>) mValuesField.get(cache);
                if (mValues != null) {
                    mValues.put("android_id",             fakeId);
                    mValues.put("google_gsf_android_id",  fakeId);
                    mValues.put("gsf_id",                 fakeId);
                    Log.i(TAG, "installInProcess: mValues pre-filled id=" + fakeId);
                }
            }
        } catch (Throwable t) {
            Log.w(TAG, "installInProcess: mValues pre-fill FAILED: " + t);
        }

        // ── Step 2: Wrap mContentProvider (belt-and-suspenders) ───────────────
        try {
            Field holderField = findField(cache.getClass(), "mProviderHolder");
            Object holder = holderField.get(cache);
            if (holder != null) {
                Field providerField = findField(holder.getClass(), "mContentProvider");
                Object orig = providerField.get(holder);
                if (orig != null) {
                    providerField.set(holder, wrapProvider(orig, fakeId, state));
                    Log.i(TAG, "installInProcess: mContentProvider WRAPPED id=" + fakeId);
                }
            }
        } catch (Throwable t) {
            Log.w(TAG, "installInProcess: mContentProvider wrap FAILED: " + t);
        }

        // ── Step 3: Wrap ActivityThread.mProviderMap (pre-acquired providers) ──
        try {
            Object at = Class.forName("android.app.ActivityThread")
                .getDeclaredMethod("currentActivityThread").invoke(null);
            Field mapField = findField(at.getClass(), "mProviderMap");
            Map<?, ?> map = (Map<?, ?>) mapField.get(at);
            if (map != null) {
                for (Map.Entry<?, ?> entry : map.entrySet()) {
                    if (entry.getKey() instanceof String
                            && isSettingsAuth((String) entry.getKey())) {
                        Object rec = entry.getValue();
                        Field pf   = findField(rec.getClass(), "provider");
                        Object p   = pf.get(rec);
                        if (p != null) pf.set(rec, wrapProvider(p, fakeId, state));
                    }
                }
                Log.i(TAG, "installInProcess: mProviderMap wrapped");
            }
        } catch (Throwable t) {
            Log.w(TAG, "installInProcess: mProviderMap hook skipped: " + t);
        }

        Log.i(TAG, "installInProcess: in-process hook complete id=" + fakeId);
    }

    private static void setSettingsWrapper(final String fakeId, final OverrideState state) {
        try {
            final Class<?> wrapperIface = Class.forName(
                "com.mundo.fake.service.IActivityManagerProxy$SettingsProviderWrapper");
            Class<?> proxyClass = Class.forName(
                "com.mundo.fake.service.IActivityManagerProxy");

            Field f = null;
            for (Field candidate : proxyClass.getDeclaredFields()) {
                if (candidate.getType() == wrapperIface) {
                    candidate.setAccessible(true);
                    f = candidate;
                    break;
                }
            }
            if (f == null) {
                Log.w(TAG, "setSettingsWrapper FAILED — no SettingsProviderWrapper field found");
                com.bgmi.ArkLogger.log("HOOK",
                    "setSettingsWrapper: SettingsProviderWrapper field NOT FOUND (AAR version mismatch?)");
                return;
            }

            Object wrapper = Proxy.newProxyInstance(
                VirtualAndroidIdHook.class.getClassLoader(),
                new Class[]{ wrapperIface },
                (proxy, method, args) -> {
                    com.bgmi.ArkLogger.log("WRAP",
                        "SettingsProviderWrapper.wrap() called — applySettingsWrapper fired");
                    if (args != null && args.length == 1)
                        return wrapProvider(args[0], fakeId, state);
                    return null;
                });
            f.set(null, wrapper);
            Log.i(TAG, "setSettingsWrapper: SET OK id=" + fakeId);
            com.bgmi.ArkLogger.log("HOOK", "setSettingsWrapper: field SET OK, id=" + fakeId);
        } catch (Throwable t) {
            Log.w(TAG, "setSettingsWrapper FAILED: " + t);
            com.bgmi.ArkLogger.log("HOOK", "setSettingsWrapper FAILED: " + t);
        }
    }

    static Object wrapProvider(Object provider, String fakeId, OverrideState state) {
        if (provider == null) return null;
        if (Proxy.isProxyClass(provider.getClass())
                && Proxy.getInvocationHandler(provider) instanceof Handler) {
            return provider;
        }
        try {
            return Proxy.newProxyInstance(
                VirtualAndroidIdHook.class.getClassLoader(),
                new Class[]{ Class.forName("android.content.IContentProvider") },
                new Handler(provider, fakeId, state));
        } catch (Throwable t) {
            Log.w(TAG, "wrapProvider FAILED: " + t);
            return provider;
        }
    }

    static Field findField(Class<?> cls, String name) throws NoSuchFieldException {
        for (Class<?> c = cls; c != null; c = c.getSuperclass()) {
            try {
                Field f = c.getDeclaredField(name);
                f.setAccessible(true);
                return f;
            } catch (NoSuchFieldException ignored) {}
        }
        throw new NoSuchFieldException(name + " in " + cls);
    }

    private static boolean isSettingsAuth(String auth) {
        return "settings".equals(auth) || (auth != null && auth.matches("[0-9]+@settings"));
    }

    // ── IContentProvider Proxy Handler ─────────────────────────────────────────

    public static final class Handler implements InvocationHandler {
        private final Object        mOriginal;
        private final String        mFakeId;
        private final OverrideState mState;

        Handler(Object original, String fakeId, OverrideState state) {
            mOriginal = original;
            mFakeId   = fakeId;
            mState    = state;
        }

        @Override
        public Object invoke(Object proxy, Method method, Object[] args) throws Throwable {
            if (mState == OverrideState.PASSTHROUGH) {
                return method.invoke(mOriginal, args);
            }

            // Count args from END — works on every API level:
            //   API <26:  call(method, arg, extras)                    len=3
            //   API 26-29: call(callingPkg, method, arg, extras)       len=4
            //   API 30+:  call(callingPkg, attribution, method, arg, extras) len=5
            if ("call".equals(method.getName()) && args != null && args.length >= 3) {
                int len = args.length;
                Object methodArg = args[len - 3];
                Object keyArg    = args[len - 2];
                if ("GET_secure".equals(methodArg)) {
                    String key = keyArg instanceof String ? (String) keyArg : "";
                    if ("android_id".equals(key)
                            || "google_gsf_android_id".equals(key)
                            || "gsf_id".equals(key)) {
                        sConfirmedId = mFakeId;
                        Bundle b = new Bundle();
                        b.putString("value", mFakeId);
                        Log.i(TAG, "Handler.call: returning fake " + key + "=" + mFakeId);
                        try {
                            com.bgmi.ArkLogger.log("READ", "BGMI called GET_secure(" + key + ")");
                            com.bgmi.ArkLogger.log("READ", "Returned fake ID  = " + mFakeId);
                            com.bgmi.ArkLogger.log("READ", "Thread            = "
                                + Thread.currentThread().getName());
                        } catch (Throwable ignored) {}
                        return b;
                    }
                    // GMS checkin guard keys
                    if ("security_token".equals(key)
                            || key.startsWith("checkin_")
                            || "last_checkin_msec".equals(key)) {
                        Bundle b = new Bundle();
                        b.putString("value", "0");
                        return b;
                    }
                }
            }

            try {
                Object result = method.invoke(mOriginal, args);
                // query() interception (cursor-based android_id read)
                if ("query".equals(method.getName())
                        && result instanceof Cursor && args != null) {
                    Uri uri = null; Bundle qb = null;
                    for (Object a : args) {
                        if (a instanceof Uri)    uri = (Uri) a;
                        if (a instanceof Bundle) qb  = (Bundle) a;
                    }
                    if (uri != null && "settings".equals(uri.getAuthority())
                            && ("/secure".equals(uri.getPath())
                                || "/secure/android_id".equals(uri.getPath()))) {
                        final boolean directId = "/secure/android_id".equals(uri.getPath());
                        boolean byQuery = false;
                        if (qb != null) {
                            String sel  = qb.getString("android:query-arg-sql-selection");
                            String[] sa = qb.getStringArray("android:query-arg-sql-selection-args");
                            if ("name=?".equals(sel != null ? sel.replace(" ", "") : "")
                                    && sa != null && sa.length == 1 && "android_id".equals(sa[0]))
                                byQuery = true;
                        }
                        final boolean matchId = directId || byQuery;
                        final String fake = mFakeId;
                        return new CursorWrapper((Cursor) result) {
                            @Override public String getString(int col) {
                                int vc = getColumnIndex("value");
                                int nc = getColumnIndex("name");
                                if (col == vc && (matchId || (nc >= 0
                                        && "android_id".equals(super.getString(nc))))) {
                                    sConfirmedId = fake;
                                    return fake;
                                }
                                return super.getString(col);
                            }
                        };
                    }
                }
                return result;
            } catch (InvocationTargetException e) {
                throw e.getCause();
            }
        }
    }
}
