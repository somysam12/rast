package com.bgmi.deviceid;

import android.content.Context;
import android.content.SharedPreferences;
import android.util.Log;

import java.security.SecureRandom;

public final class VirtualDeviceIdStore {

    private static final String TAG      = "VirtualDeviceIdStore";
    private static final String PREF_FILE = "ark_deviceid";
    private static final String KEY_DESIRED = "ark_devid_desired";

    private final SharedPreferences mPrefs;

    public VirtualDeviceIdStore(Context ctx) {
        // Do NOT call getApplicationContext() here — it returns null during attachBaseContext.
        // Any context in the same process + package gives the same SharedPreferences file.
        Context c = (ctx != null) ? ctx : null;
        if (c == null) throw new IllegalArgumentException("null context");
        mPrefs = c.getSharedPreferences(PREF_FILE, Context.MODE_PRIVATE);
    }

    /** Returns the stored fake device ID, or empty string if none stored yet. */
    public String desired() {
        return mPrefs.getString(KEY_DESIRED, "");
    }

    /**
     * Generates a new random 16-char hex ID, persists it, and returns it.
     * Call this when the user taps "Change Device ID".
     */
    public String change() {
        String newId = Long.toHexString(new SecureRandom().nextLong());
        mPrefs.edit().putString(KEY_DESIRED, newId).apply();
        Log.i(TAG, "change: new device id=" + newId);
        return newId;
    }

    public void report(String raw, String assigned, String action, String note) {
        Log.i(TAG, "report raw=" + raw + " assigned=" + assigned
                + " action=" + action + " note=" + note);
    }
}
