package com.bgmi;
import com.bgmi.R;
import com.bgmi.logger.ArkCrashLogger;

import android.content.Intent;
import android.graphics.Color;
import android.graphics.PixelFormat;
import android.graphics.PorterDuff;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.Environment;
import android.os.Handler;
import android.os.Looper;
import android.provider.Settings;
import android.view.View;
import android.view.animation.AccelerateInterpolator;
import android.view.animation.AccelerateDecelerateInterpolator;
import android.view.animation.OvershootInterpolator;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ProgressBar;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.AppCompatButton;

import com.bgmi.utils.Prefs;
import com.google.android.material.bottomsheet.BottomSheetDialog;

import com.mundo.MundoCore;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.InputStream;
import java.io.OutputStream;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.concurrent.atomic.AtomicBoolean;

@SuppressWarnings({"unused","deprecation"})
public class MainActivity extends AppCompatActivity {

    // libshaitaan loaded by ArkApplication
    public static native String exdate();

    private static final String PKG_BGMI    = "com.pubg.imobile";
    private static final long   DELAY       = 1200L;
    private static final String KEY_OBB_DONE = "ark_obb_copied";

    private final Handler mainHandler = new Handler(Looper.getMainLooper());

    private LinearLayout    licenseLayout;
    private LinearLayout    processingLayout;
    private android.widget.LinearLayout copyObbView;
    private TextView        statusText;
    private TextView        syncText;
    private ProgressBar     obbProgressBar;
    private TextView        obbPercentText;
    private TextView        obbSizeText;
    private TextView        tvD, tvH, tvM, tvS;
    private TextView        expiryDateTv;
    private AppCompatButton btnAction;
    private LinearLayout    bgmiInstalledRow;
    private BottomSheetDialog bsd;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        buildMainLayout();

        startCountdown();
        boolean alreadyDone = new Prefs(this).getBool(KEY_OBB_DONE, false);
        setButtonState(alreadyDone);
    }

    // ── Programmatic fire-themed launch screen ────────────────────────────────
    private void buildMainLayout() {
        android.widget.FrameLayout root = new android.widget.FrameLayout(this);
        root.setBackgroundColor(android.graphics.Color.BLACK);

        android.widget.ScrollView scroll = new android.widget.ScrollView(this);
        scroll.setVerticalScrollBarEnabled(false);
        android.widget.LinearLayout col = new android.widget.LinearLayout(this);
        col.setOrientation(android.widget.LinearLayout.VERTICAL);
        col.setGravity(android.view.Gravity.CENTER_HORIZONTAL);
        col.setPadding(dp(20), dp(52), dp(20), dp(32));

        // ── aRkCheat flame text ───────────────────────────────────────────────
        android.widget.ImageView flameImg = new android.widget.ImageView(this);
        flameImg.setImageResource(R.drawable.ark_flame_text);
        flameImg.setScaleType(android.widget.ImageView.ScaleType.FIT_CENTER);
        android.widget.LinearLayout.LayoutParams fiLp =
            new android.widget.LinearLayout.LayoutParams(dp(260), dp(143));
        fiLp.gravity = android.view.Gravity.CENTER_HORIZONTAL;
        fiLp.bottomMargin = dp(12);
        flameImg.setLayoutParams(fiLp);
        col.addView(flameImg);

        // ── Expiry date ───────────────────────────────────────────────────────
        expiryDateTv = new TextView(this);
        expiryDateTv.setText("");
        expiryDateTv.setTextColor(android.graphics.Color.parseColor("#886644"));
        try { expiryDateTv.setTypeface(androidx.core.content.res.ResourcesCompat.getFont(this, R.font.bold)); } catch (Throwable ignored) {}
        expiryDateTv.setTextSize(android.util.TypedValue.COMPLEX_UNIT_SP, 10);
        expiryDateTv.setGravity(android.view.Gravity.CENTER);
        android.widget.LinearLayout.LayoutParams edLp =
            new android.widget.LinearLayout.LayoutParams(
                android.widget.LinearLayout.LayoutParams.MATCH_PARENT,
                android.widget.LinearLayout.LayoutParams.WRAP_CONTENT);
        edLp.bottomMargin = dp(14);
        expiryDateTv.setLayoutParams(edLp);
        col.addView(expiryDateTv);

        // ── Countdown — minimal pill style ──────────────────────────────────────
        // Outer container: full-width pill with subtle orange border
        android.widget.LinearLayout timerRow = new android.widget.LinearLayout(this);
        timerRow.setOrientation(android.widget.LinearLayout.HORIZONTAL);
        timerRow.setGravity(android.view.Gravity.CENTER_VERTICAL);
        android.graphics.drawable.GradientDrawable timerBg = new android.graphics.drawable.GradientDrawable();
        timerBg.setColor(android.graphics.Color.parseColor("#0F0800"));
        timerBg.setCornerRadius(dp(50));
        timerBg.setStroke(dp(1), android.graphics.Color.parseColor("#33FF8800"));
        timerRow.setBackground(timerBg);
        timerRow.setPadding(dp(18), dp(12), dp(18), dp(12));
        android.widget.LinearLayout.LayoutParams trLp =
            new android.widget.LinearLayout.LayoutParams(
                android.widget.LinearLayout.LayoutParams.MATCH_PARENT,
                android.widget.LinearLayout.LayoutParams.WRAP_CONTENT);
        trLp.bottomMargin = dp(20);
        timerRow.setLayoutParams(trLp);

        String[] cdLabels = {"D", "H", "M", "S"};
        TextView[] cdViews = new TextView[4];
        int[] accentColors = {
            android.graphics.Color.parseColor("#FF8800"),
            android.graphics.Color.parseColor("#FF8800"),
            android.graphics.Color.parseColor("#FF8800"),
            android.graphics.Color.parseColor("#FF3D0A")
        };

        for (int i = 0; i < 4; i++) {
            // Each unit: number + label stacked, weight=1
            android.widget.LinearLayout unitCol = new android.widget.LinearLayout(this);
            unitCol.setOrientation(android.widget.LinearLayout.VERTICAL);
            unitCol.setGravity(android.view.Gravity.CENTER);
            android.widget.LinearLayout.LayoutParams ucLp =
                new android.widget.LinearLayout.LayoutParams(
                    0, android.widget.LinearLayout.LayoutParams.WRAP_CONTENT, 1f);
            unitCol.setLayoutParams(ucLp);

            // Number text — large, bold, no box
            cdViews[i] = new TextView(this);
            cdViews[i].setText("00");
            cdViews[i].setTextColor(accentColors[i]);
            cdViews[i].setTextSize(android.util.TypedValue.COMPLEX_UNIT_SP, 28);
            cdViews[i].setGravity(android.view.Gravity.CENTER);
            cdViews[i].setLineSpacing(0, 1f);
            try { cdViews[i].setTypeface(androidx.core.content.res.ResourcesCompat.getFont(this, R.font.bold)); }
            catch (Throwable ignored) {}
            android.widget.LinearLayout.LayoutParams numLp =
                new android.widget.LinearLayout.LayoutParams(
                    android.widget.LinearLayout.LayoutParams.WRAP_CONTENT,
                    android.widget.LinearLayout.LayoutParams.WRAP_CONTENT);
            cdViews[i].setLayoutParams(numLp);
            unitCol.addView(cdViews[i]);

            // Label text — tiny, muted
            TextView lbl = new TextView(this);
            lbl.setText(cdLabels[i]);
            lbl.setTextColor(android.graphics.Color.parseColor("#55443300"));
            lbl.setTextColor(android.graphics.Color.parseColor("#664422"));
            lbl.setTextSize(android.util.TypedValue.COMPLEX_UNIT_SP, 9);
            lbl.setLetterSpacing(0.20f);
            lbl.setGravity(android.view.Gravity.CENTER);
            android.widget.LinearLayout.LayoutParams lblLp =
                new android.widget.LinearLayout.LayoutParams(
                    android.widget.LinearLayout.LayoutParams.WRAP_CONTENT,
                    android.widget.LinearLayout.LayoutParams.WRAP_CONTENT);
            lblLp.topMargin = dp(1);
            lbl.setLayoutParams(lblLp);
            unitCol.addView(lbl);

            timerRow.addView(unitCol);

            // Thin vertical divider between units (not after last)
            if (i < 3) {
                android.view.View sep = new android.view.View(this);
                sep.setBackgroundColor(android.graphics.Color.parseColor("#22FF8800"));
                android.widget.LinearLayout.LayoutParams sepLp =
                    new android.widget.LinearLayout.LayoutParams(dp(1), dp(32));
                sep.setLayoutParams(sepLp);
                timerRow.addView(sep);
            }
        }
        tvD = cdViews[0]; tvH = cdViews[1]; tvM = cdViews[2]; tvS = cdViews[3];
        col.addView(timerRow);

        // ── BGMI game card — like image 1 ─────────────────────────────────────
        android.widget.LinearLayout gameCard = new android.widget.LinearLayout(this);
        gameCard.setOrientation(android.widget.LinearLayout.VERTICAL);
        android.graphics.drawable.GradientDrawable gcBg = new android.graphics.drawable.GradientDrawable();
        gcBg.setCornerRadius(dp(16));
        gcBg.setColor(android.graphics.Color.parseColor("#111111"));
        gcBg.setStroke(dp(1), android.graphics.Color.parseColor("#222222"));
        gameCard.setBackground(gcBg);
        gameCard.setPadding(dp(16), dp(14), dp(16), dp(16));
        android.widget.LinearLayout.LayoutParams gcLp =
            new android.widget.LinearLayout.LayoutParams(
                android.widget.LinearLayout.LayoutParams.MATCH_PARENT,
                android.widget.LinearLayout.LayoutParams.WRAP_CONTENT);
        gcLp.bottomMargin = dp(14);
        gameCard.setLayoutParams(gcLp);

        // Game info row
        android.widget.LinearLayout infoRow = new android.widget.LinearLayout(this);
        infoRow.setOrientation(android.widget.LinearLayout.HORIZONTAL);
        infoRow.setGravity(android.view.Gravity.CENTER_VERTICAL);
        android.widget.LinearLayout.LayoutParams irLp =
            new android.widget.LinearLayout.LayoutParams(
                android.widget.LinearLayout.LayoutParams.MATCH_PARENT,
                android.widget.LinearLayout.LayoutParams.WRAP_CONTENT);
        irLp.bottomMargin = dp(14);
        infoRow.setLayoutParams(irLp);

        // BGMI icon — rounded corners via outline clipping
        android.widget.ImageView bgmiIco = new android.widget.ImageView(this);
        bgmiIco.setImageResource(R.drawable.ic_bgmi);
        bgmiIco.setScaleType(android.widget.ImageView.ScaleType.CENTER_CROP);
        android.graphics.drawable.GradientDrawable iconBg = new android.graphics.drawable.GradientDrawable();
        iconBg.setCornerRadius(dp(14));
        iconBg.setColor(android.graphics.Color.parseColor("#1A1A1A"));
        bgmiIco.setBackground(iconBg);
        bgmiIco.setClipToOutline(true);
        android.graphics.Outline icoOutline = new android.graphics.Outline();
        bgmiIco.setOutlineProvider(new android.view.ViewOutlineProvider() {
            @Override
            public void getOutline(android.view.View view, android.graphics.Outline outline) {
                float r = dp(14);
                outline.setRoundRect(0, 0, view.getWidth(), view.getHeight(), r);
            }
        });
        android.widget.LinearLayout.LayoutParams icoLp =
            new android.widget.LinearLayout.LayoutParams(dp(60), dp(60));
        icoLp.rightMargin = dp(12);
        bgmiIco.setLayoutParams(icoLp);
        infoRow.addView(bgmiIco);

        // Game name + package + status
        android.widget.LinearLayout nameCol = new android.widget.LinearLayout(this);
        nameCol.setOrientation(android.widget.LinearLayout.VERTICAL);
        nameCol.setLayoutParams(new android.widget.LinearLayout.LayoutParams(0,
            android.widget.LinearLayout.LayoutParams.WRAP_CONTENT, 1f));

        TextView nameTv = new TextView(this);
        nameTv.setText("Battlegrounds India");
        try { nameTv.setTypeface(androidx.core.content.res.ResourcesCompat.getFont(this, R.font.bold)); } catch (Throwable ignored) {}
        nameTv.setTextColor(android.graphics.Color.WHITE);
        nameTv.setTextSize(android.util.TypedValue.COMPLEX_UNIT_SP, 15);
        try { nameTv.setTypeface(androidx.core.content.res.ResourcesCompat.getFont(this, R.font.bold)); }
        catch (Throwable ignored) {}
        nameCol.addView(nameTv);

        TextView pkgTv = new TextView(this);
        pkgTv.setText("com.pubg.imobile");
        try { pkgTv.setTypeface(androidx.core.content.res.ResourcesCompat.getFont(this, R.font.bold)); } catch (Throwable ignored) {}
        pkgTv.setTextColor(android.graphics.Color.parseColor("#888888"));
        pkgTv.setTextSize(android.util.TypedValue.COMPLEX_UNIT_SP, 10);
        nameCol.addView(pkgTv);

        // Status row with checkmark dot
        android.widget.LinearLayout statusRow = new android.widget.LinearLayout(this);
        statusRow.setOrientation(android.widget.LinearLayout.HORIZONTAL);
        statusRow.setGravity(android.view.Gravity.CENTER_VERTICAL);
        android.widget.LinearLayout.LayoutParams srLp =
            new android.widget.LinearLayout.LayoutParams(
                android.widget.LinearLayout.LayoutParams.WRAP_CONTENT,
                android.widget.LinearLayout.LayoutParams.WRAP_CONTENT);
        srLp.topMargin = dp(4);
        statusRow.setLayoutParams(srLp);

        statusText = new TextView(this);
        statusText.setText("Ready to launch");
        try { statusText.setTypeface(androidx.core.content.res.ResourcesCompat.getFont(this, R.font.bold)); } catch (Throwable ignored) {}
        statusText.setTextColor(android.graphics.Color.parseColor("#FFA500"));
        statusText.setTextSize(android.util.TypedValue.COMPLEX_UNIT_SP, 10);
        statusRow.addView(statusText);

        nameCol.addView(statusRow);
        infoRow.addView(nameCol);

        // BGMI pill badge
        TextView bgmiBadge = new TextView(this);
        bgmiBadge.setText("BGMI");
        try { bgmiBadge.setTypeface(androidx.core.content.res.ResourcesCompat.getFont(this, R.font.bold)); } catch (Throwable ignored) {}
        bgmiBadge.setTextColor(android.graphics.Color.parseColor("#44FF88"));
        bgmiBadge.setTextSize(android.util.TypedValue.COMPLEX_UNIT_SP, 10);
        bgmiBadge.setLetterSpacing(0.08f);
        android.graphics.drawable.GradientDrawable badgeBg = new android.graphics.drawable.GradientDrawable();
        badgeBg.setCornerRadius(dp(20));
        badgeBg.setColor(android.graphics.Color.TRANSPARENT);
        badgeBg.setStroke(dp(1), android.graphics.Color.parseColor("#44FF88"));
        bgmiBadge.setBackground(badgeBg);
        bgmiBadge.setPadding(dp(10), dp(4), dp(10), dp(4));
        infoRow.addView(bgmiBadge);

        gameCard.addView(infoRow);

        // ── Action buttons row — LAUNCH + COPY OBB like image 1 ──────────────
        android.widget.LinearLayout btnRow2 = new android.widget.LinearLayout(this);
        btnRow2.setOrientation(android.widget.LinearLayout.HORIZONTAL);
        btnRow2.setGravity(android.view.Gravity.CENTER_VERTICAL);
        android.widget.LinearLayout.LayoutParams br2Lp =
            new android.widget.LinearLayout.LayoutParams(
                android.widget.LinearLayout.LayoutParams.MATCH_PARENT,
                android.widget.LinearLayout.LayoutParams.WRAP_CONTENT);
        btnRow2.setLayoutParams(br2Lp);

        // LAUNCH button — dark amber pill, orange text
        btnAction = new androidx.appcompat.widget.AppCompatButton(this);
        android.graphics.drawable.GradientDrawable launchBg = new android.graphics.drawable.GradientDrawable(
            android.graphics.drawable.GradientDrawable.Orientation.LEFT_RIGHT,
            new int[]{android.graphics.Color.parseColor("#2A1A00"), android.graphics.Color.parseColor("#1A1000")});
        launchBg.setCornerRadius(dp(28));
        launchBg.setStroke(dp(1), android.graphics.Color.parseColor("#33FF8800"));
        btnAction.setBackground(launchBg);
        btnAction.setText("LAUNCH");
        btnAction.setTextColor(android.graphics.Color.parseColor("#FF8800"));
        btnAction.setTextSize(android.util.TypedValue.COMPLEX_UNIT_SP, 14);
        btnAction.setLetterSpacing(0.12f);
        try { btnAction.setTypeface(androidx.core.content.res.ResourcesCompat.getFont(this, R.font.bold)); }
        catch (Throwable ignored) {}
        android.widget.LinearLayout.LayoutParams launchLp =
            new android.widget.LinearLayout.LayoutParams(0, dp(52), 1.6f);
        launchLp.rightMargin = dp(8);
        btnAction.setLayoutParams(launchLp);
        btnRow2.addView(btnAction);

        // COPY OBB button — dark grey pill
        android.widget.LinearLayout copyObbLl = new android.widget.LinearLayout(this);
        copyObbLl.setOrientation(android.widget.LinearLayout.VERTICAL);
        copyObbLl.setGravity(android.view.Gravity.CENTER);
        android.graphics.drawable.GradientDrawable obbBg = new android.graphics.drawable.GradientDrawable();
        obbBg.setCornerRadius(dp(28));
        obbBg.setColor(android.graphics.Color.parseColor("#1A1A1A"));
        obbBg.setStroke(dp(1), android.graphics.Color.parseColor("#333333"));
        copyObbLl.setBackground(obbBg);
        copyObbLl.setPadding(dp(12), dp(10), dp(12), dp(10));
        android.widget.LinearLayout.LayoutParams obbLp =
            new android.widget.LinearLayout.LayoutParams(0, dp(52), 1f);
        copyObbLl.setLayoutParams(obbLp);

        android.widget.ImageView obbIco = new android.widget.ImageView(this);
        obbIco.setImageResource(R.drawable.ic_copy_obb);
        obbIco.setColorFilter(android.graphics.Color.WHITE, android.graphics.PorterDuff.Mode.SRC_IN);
        obbIco.setScaleType(android.widget.ImageView.ScaleType.FIT_CENTER);
        copyObbLl.addView(obbIco, new android.widget.LinearLayout.LayoutParams(dp(20), dp(20)));
        TextView obbTxt = new TextView(this);
        obbTxt.setText("COPY\nOBB");
        try { obbTxt.setTypeface(androidx.core.content.res.ResourcesCompat.getFont(this, R.font.bold)); } catch (Throwable ignored) {}
        obbTxt.setTextColor(android.graphics.Color.WHITE);
        obbTxt.setTextSize(android.util.TypedValue.COMPLEX_UNIT_SP, 10);
        obbTxt.setGravity(android.view.Gravity.CENTER);
        obbTxt.setLetterSpacing(0.08f);
        copyObbLl.addView(obbTxt, new android.widget.LinearLayout.LayoutParams(
            android.widget.LinearLayout.LayoutParams.WRAP_CONTENT,
            android.widget.LinearLayout.LayoutParams.WRAP_CONTENT));
        copyObbLl.setOnClickListener(v -> startObbCopy());
        btnRow2.addView(copyObbLl);
        copyObbView = copyObbLl; // keep ref for setButtonState

        gameCard.addView(btnRow2);
        col.addView(gameCard);

        // ── bgmiInstalledRow (hidden, shown when game ready) ──────────────────
        bgmiInstalledRow = new LinearLayout(this);
        bgmiInstalledRow.setVisibility(View.GONE);
        col.addView(bgmiInstalledRow, new android.widget.LinearLayout.LayoutParams(
            android.widget.LinearLayout.LayoutParams.MATCH_PARENT, dp(0)));

        // ── licenseLayout + processingLayout wrappers ─────────────────────────
        licenseLayout = new LinearLayout(this);
        licenseLayout.setVisibility(View.GONE);
        col.addView(licenseLayout, new android.widget.LinearLayout.LayoutParams(
            android.widget.LinearLayout.LayoutParams.MATCH_PARENT, dp(0)));

        processingLayout = new LinearLayout(this);
        ((LinearLayout)processingLayout).setOrientation(LinearLayout.VERTICAL);
        ((LinearLayout)processingLayout).setGravity(android.view.Gravity.CENTER_HORIZONTAL);
        android.graphics.drawable.GradientDrawable plBg = new android.graphics.drawable.GradientDrawable();
        plBg.setCornerRadius(dp(12));
        plBg.setColor(android.graphics.Color.parseColor("#111111"));
        plBg.setStroke(dp(1), android.graphics.Color.parseColor("#332200"));
        ((LinearLayout)processingLayout).setBackground(plBg);
        ((LinearLayout)processingLayout).setPadding(dp(18), dp(16), dp(18), dp(16));
        android.widget.LinearLayout.LayoutParams plLp =
            new android.widget.LinearLayout.LayoutParams(
                android.widget.LinearLayout.LayoutParams.MATCH_PARENT,
                android.widget.LinearLayout.LayoutParams.WRAP_CONTENT);
        plLp.topMargin = dp(10);
        processingLayout.setLayoutParams(plLp);

        syncText = new TextView(this);
        syncText.setText("Copying OBB data...");
        syncText.setTextColor(android.graphics.Color.WHITE);
        syncText.setTextSize(android.util.TypedValue.COMPLEX_UNIT_SP, 12);
        syncText.setGravity(android.view.Gravity.CENTER);
        ((LinearLayout)processingLayout).addView(syncText,
            new android.widget.LinearLayout.LayoutParams(
                android.widget.LinearLayout.LayoutParams.MATCH_PARENT,
                android.widget.LinearLayout.LayoutParams.WRAP_CONTENT));

        obbProgressBar = new ProgressBar(this, null, android.R.attr.progressBarStyleHorizontal);
        obbProgressBar.setMax(100);
        android.widget.LinearLayout.LayoutParams opbLp =
            new android.widget.LinearLayout.LayoutParams(
                android.widget.LinearLayout.LayoutParams.MATCH_PARENT, dp(5));
        opbLp.topMargin = dp(10); opbLp.bottomMargin = dp(6);
        obbProgressBar.setLayoutParams(opbLp);
        ((LinearLayout)processingLayout).addView(obbProgressBar);

        android.widget.LinearLayout pctRow = new android.widget.LinearLayout(this);
        pctRow.setOrientation(android.widget.LinearLayout.HORIZONTAL);
        pctRow.setGravity(android.view.Gravity.CENTER);
        obbPercentText = new TextView(this);
        obbPercentText.setTextColor(android.graphics.Color.parseColor("#FF8800"));
        obbPercentText.setTextSize(android.util.TypedValue.COMPLEX_UNIT_SP, 11);
        pctRow.addView(obbPercentText);
        obbSizeText = new TextView(this);
        obbSizeText.setTextColor(android.graphics.Color.parseColor("#555533"));
        obbSizeText.setTextSize(android.util.TypedValue.COMPLEX_UNIT_SP, 10);
        android.widget.LinearLayout.LayoutParams ostLp =
            new android.widget.LinearLayout.LayoutParams(
                android.widget.LinearLayout.LayoutParams.WRAP_CONTENT,
                android.widget.LinearLayout.LayoutParams.WRAP_CONTENT);
        ostLp.leftMargin = dp(8); obbSizeText.setLayoutParams(ostLp);
        pctRow.addView(obbSizeText);
        ((LinearLayout)processingLayout).addView(pctRow,
            new android.widget.LinearLayout.LayoutParams(
                android.widget.LinearLayout.LayoutParams.MATCH_PARENT,
                android.widget.LinearLayout.LayoutParams.WRAP_CONTENT));
        processingLayout.setVisibility(View.GONE);
        col.addView(processingLayout);

        // ── Facebook Login Guide button ───────────────────────────────────────
        android.widget.LinearLayout fbGuideBtn = new android.widget.LinearLayout(this);
        fbGuideBtn.setOrientation(android.widget.LinearLayout.HORIZONTAL);
        fbGuideBtn.setGravity(android.view.Gravity.CENTER_VERTICAL);
        android.graphics.drawable.GradientDrawable fbBtnBg = new android.graphics.drawable.GradientDrawable();
        fbBtnBg.setCornerRadius(dp(12));
        fbBtnBg.setColor(android.graphics.Color.parseColor("#0D0A1A"));
        fbBtnBg.setStroke(dp(1), android.graphics.Color.parseColor("#1877F2"));
        fbGuideBtn.setBackground(fbBtnBg);
        fbGuideBtn.setPadding(dp(14), dp(12), dp(14), dp(12));
        android.widget.LinearLayout.LayoutParams fbGuideLp =
            new android.widget.LinearLayout.LayoutParams(
                android.widget.LinearLayout.LayoutParams.MATCH_PARENT,
                android.widget.LinearLayout.LayoutParams.WRAP_CONTENT);
        fbGuideLp.topMargin = dp(12);
        fbGuideBtn.setLayoutParams(fbGuideLp);

        android.widget.ImageView fbIco = new android.widget.ImageView(this);
        fbIco.setImageResource(R.drawable.ic_fb);
        fbIco.setScaleType(android.widget.ImageView.ScaleType.FIT_CENTER);
        android.widget.LinearLayout.LayoutParams fbIcoLp =
            new android.widget.LinearLayout.LayoutParams(dp(28), dp(28));
        fbIcoLp.rightMargin = dp(10);
        fbIco.setLayoutParams(fbIcoLp);
        fbGuideBtn.addView(fbIco);

        android.widget.LinearLayout fbTextCol = new android.widget.LinearLayout(this);
        fbTextCol.setOrientation(android.widget.LinearLayout.VERTICAL);
        fbTextCol.setLayoutParams(new android.widget.LinearLayout.LayoutParams(0,
            android.widget.LinearLayout.LayoutParams.WRAP_CONTENT, 1f));
        TextView fbTitle = new TextView(this);
        fbTitle.setText("Tutorial: Facebook Login Guide");
        fbTitle.setTextColor(android.graphics.Color.WHITE);
        fbTitle.setTextSize(android.util.TypedValue.COMPLEX_UNIT_SP, 12);
        try { fbTitle.setTypeface(androidx.core.content.res.ResourcesCompat.getFont(this, R.font.bold)); }
        catch (Throwable ignored) {}
        fbTextCol.addView(fbTitle);
        TextView fbSub = new TextView(this);
        fbSub.setText("Tap to view step-by-step guide");
        fbSub.setTextColor(android.graphics.Color.parseColor("#888888"));
        fbSub.setTextSize(android.util.TypedValue.COMPLEX_UNIT_SP, 9);
        fbTextCol.addView(fbSub);
        fbGuideBtn.addView(fbTextCol);

        TextView fbArrow = new TextView(this);
        fbArrow.setText("›");
        fbArrow.setTextColor(android.graphics.Color.parseColor("#1877F2"));
        fbArrow.setTextSize(android.util.TypedValue.COMPLEX_UNIT_SP, 22);
        fbGuideBtn.addView(fbArrow);

        fbGuideBtn.setOnClickListener(v -> showFbGuideDialog());
        col.addView(fbGuideBtn);

        scroll.addView(col);
        root.addView(scroll, new android.widget.FrameLayout.LayoutParams(
            android.widget.FrameLayout.LayoutParams.MATCH_PARENT,
            android.widget.FrameLayout.LayoutParams.MATCH_PARENT));

        setContentView(root);
    }

    // ── Facebook Login Guide Dialog — smooth 120fps spring animation ──────────
    private boolean fbLangHindi = false;
    private static final String FB_GUIDE_EN =
        "To login with Facebook account:\n\n" +
        "1.  Install the REAL Facebook app on your device\n\n" +
        "2.  Open aRkCheat and launch BGMI from inside it\n\n" +
        "3.  On the BGMI login screen, tap on \'Facebook Login\'\n\n" +
        "4.  You will be automatically redirected to the real Facebook app\n\n" +
        "5.  Login there — and you are done!\n\nEnjoy playing BGMI with aRkCheat.";
    private static final String FB_GUIDE_HI =
        "Facebook account se login karne ke liye:\n\n" +
        "1.  Apne device mein real Facebook app install karen\n\n" +
        "2.  aRkCheat open karen aur iske andar se BGMI launch karen\n\n" +
        "3.  BGMI login screen par \'Facebook Login\' button tap karen\n\n" +
        "4.  Aap automatically real Facebook app par redirect ho jayenge\n\n" +
        "5.  Wahan login karen — aur ho gaya!\n\naRkCheat ke saath BGMI enjoy karen.";

    private void showFbGuideDialog() {
        android.view.WindowManager wm = (android.view.WindowManager) getSystemService(android.content.Context.WINDOW_SERVICE);
        if (wm == null) return;

        // Scrim
        android.widget.FrameLayout scrim = new android.widget.FrameLayout(this);
        scrim.setBackgroundColor(android.graphics.Color.parseColor("#CC000000"));

        // Card
        android.widget.LinearLayout card = new android.widget.LinearLayout(this);
        card.setOrientation(android.widget.LinearLayout.VERTICAL);
        card.setPadding(dp(22), dp(20), dp(22), dp(20));
        android.graphics.drawable.GradientDrawable cardBg = new android.graphics.drawable.GradientDrawable();
        cardBg.setCornerRadius(dp(18));
        cardBg.setColor(android.graphics.Color.parseColor("#111111"));
        cardBg.setStroke(dp(1), android.graphics.Color.parseColor("#1877F2"));
        card.setBackground(cardBg);
        card.setElevation(dp(12));

        // Header row
        android.widget.LinearLayout hdr = new android.widget.LinearLayout(this);
        hdr.setOrientation(android.widget.LinearLayout.HORIZONTAL);
        hdr.setGravity(android.view.Gravity.CENTER_VERTICAL);
        android.widget.LinearLayout.LayoutParams hdrLp =
            new android.widget.LinearLayout.LayoutParams(
                android.widget.LinearLayout.LayoutParams.MATCH_PARENT,
                android.widget.LinearLayout.LayoutParams.WRAP_CONTENT);
        hdrLp.bottomMargin = dp(14); hdr.setLayoutParams(hdrLp);

        android.widget.ImageView fbIcoD = new android.widget.ImageView(this);
        fbIcoD.setImageResource(R.drawable.ic_fb);
        android.widget.LinearLayout.LayoutParams fiLp2 =
            new android.widget.LinearLayout.LayoutParams(dp(32), dp(32));
        fiLp2.rightMargin = dp(10); fbIcoD.setLayoutParams(fiLp2);
        hdr.addView(fbIcoD);

        TextView hdrTv = new TextView(this);
        hdrTv.setText("Facebook Login Guide");
        hdrTv.setTextColor(android.graphics.Color.WHITE);
        hdrTv.setTextSize(android.util.TypedValue.COMPLEX_UNIT_SP, 15);
        try { hdrTv.setTypeface(androidx.core.content.res.ResourcesCompat.getFont(this, R.font.bold)); }
        catch (Throwable ignored) {}
        hdr.addView(hdrTv, new android.widget.LinearLayout.LayoutParams(0,
            android.widget.LinearLayout.LayoutParams.WRAP_CONTENT, 1f));
        card.addView(hdr);

        // Language toggle
        android.widget.LinearLayout langRow = new android.widget.LinearLayout(this);
        langRow.setOrientation(android.widget.LinearLayout.HORIZONTAL);
        langRow.setGravity(android.view.Gravity.CENTER);
        android.widget.LinearLayout.LayoutParams lrLp2 =
            new android.widget.LinearLayout.LayoutParams(
                android.widget.LinearLayout.LayoutParams.MATCH_PARENT,
                android.widget.LinearLayout.LayoutParams.WRAP_CONTENT);
        lrLp2.bottomMargin = dp(12); langRow.setLayoutParams(lrLp2);

        final TextView[] langBtns = new TextView[2];
        String[] langs = {"EN", "हिंदी"};
        for (int i = 0; i < 2; i++) {
            TextView lb = new TextView(this);
            lb.setText(langs[i]);
            lb.setGravity(android.view.Gravity.CENTER);
            lb.setTextSize(android.util.TypedValue.COMPLEX_UNIT_SP, 11);
            lb.setPadding(dp(16), dp(5), dp(16), dp(5));
            langBtns[i] = lb;
            android.widget.LinearLayout.LayoutParams lbLp =
                new android.widget.LinearLayout.LayoutParams(
                    android.widget.LinearLayout.LayoutParams.WRAP_CONTENT,
                    android.widget.LinearLayout.LayoutParams.WRAP_CONTENT);
            lbLp.leftMargin = dp(4); lbLp.rightMargin = dp(4);
            lb.setLayoutParams(lbLp);
            langRow.addView(lb);
        }
        card.addView(langRow);

        // Guide text
        android.widget.ScrollView textScroll = new android.widget.ScrollView(this);
        textScroll.setVerticalScrollBarEnabled(false);
        final TextView guideTv = new TextView(this);
        guideTv.setTextColor(android.graphics.Color.parseColor("#CCCCCC"));
        guideTv.setTextSize(android.util.TypedValue.COMPLEX_UNIT_SP, 12);
        guideTv.setLineSpacing(dp(4), 1f);
        guideTv.setText(fbLangHindi ? FB_GUIDE_HI : FB_GUIDE_EN);
        textScroll.addView(guideTv, new android.widget.LinearLayout.LayoutParams(
            android.widget.LinearLayout.LayoutParams.MATCH_PARENT,
            android.widget.LinearLayout.LayoutParams.WRAP_CONTENT));
        android.widget.LinearLayout.LayoutParams tsLp =
            new android.widget.LinearLayout.LayoutParams(
                android.widget.LinearLayout.LayoutParams.MATCH_PARENT, dp(200));
        tsLp.bottomMargin = dp(16);
        textScroll.setLayoutParams(tsLp);
        card.addView(textScroll);

        // Close button
        androidx.appcompat.widget.AppCompatButton closeBtn =
            new androidx.appcompat.widget.AppCompatButton(this);
        closeBtn.setText("GOT IT");
        android.graphics.drawable.GradientDrawable closeBg = new android.graphics.drawable.GradientDrawable();
        closeBg.setCornerRadius(dp(24));
        closeBg.setColor(android.graphics.Color.parseColor("#1877F2"));
        closeBtn.setBackground(closeBg);
        closeBtn.setTextColor(android.graphics.Color.WHITE);
        closeBtn.setTextSize(android.util.TypedValue.COMPLEX_UNIT_SP, 13);
        closeBtn.setLetterSpacing(0.12f);
        card.addView(closeBtn, new android.widget.LinearLayout.LayoutParams(
            android.widget.LinearLayout.LayoutParams.MATCH_PARENT, dp(46)));

        // Layout card centered in scrim
        android.widget.FrameLayout.LayoutParams cardLp =
            new android.widget.FrameLayout.LayoutParams(
                (int)(getResources().getDisplayMetrics().widthPixels * 0.88f),
                android.widget.FrameLayout.LayoutParams.WRAP_CONTENT);
        cardLp.gravity = android.view.Gravity.CENTER;
        scrim.addView(card, cardLp);

        // WindowManager add
        android.view.WindowManager.LayoutParams wmLp = new android.view.WindowManager.LayoutParams(
            android.view.WindowManager.LayoutParams.MATCH_PARENT,
            android.view.WindowManager.LayoutParams.MATCH_PARENT,
            android.os.Build.VERSION.SDK_INT >= 26
                ? android.view.WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY
                : android.view.WindowManager.LayoutParams.TYPE_PHONE,
            android.view.WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE,
            android.graphics.PixelFormat.TRANSLUCENT);
        wm.addView(scrim, wmLp);
        wmLp.flags &= ~android.view.WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE;
        wm.updateViewLayout(scrim, wmLp);

        // Spring-in animation at 120fps
        card.setScaleX(0.7f); card.setScaleY(0.7f); card.setAlpha(0f);
        scrim.setAlpha(0f);
        scrim.animate().alpha(1f).setDuration(200)
            .setInterpolator(new android.view.animation.AccelerateDecelerateInterpolator()).start();
        card.animate().scaleX(1f).scaleY(1f).alpha(1f).setDuration(350)
            .setInterpolator(new android.view.animation.OvershootInterpolator(1.5f)).start();

        // Apply initial lang style
        Runnable applyLang = () -> {
            for (int i = 0; i < 2; i++) {
                boolean active = (i == 1) == fbLangHindi;
                langBtns[i].setTextColor(active
                    ? android.graphics.Color.WHITE
                    : android.graphics.Color.parseColor("#666666"));
                android.graphics.drawable.GradientDrawable lbg = new android.graphics.drawable.GradientDrawable();
                lbg.setCornerRadius(dp(16));
                lbg.setColor(active
                    ? android.graphics.Color.parseColor("#1877F2")
                    : android.graphics.Color.TRANSPARENT);
                langBtns[i].setBackground(lbg);
            }
            guideTv.setText(fbLangHindi ? FB_GUIDE_HI : FB_GUIDE_EN);
        };
        applyLang.run();

        // Language toggle clicks
        for (int i = 0; i < 2; i++) {
            final boolean isHindi = (i == 1);
            langBtns[i].setOnClickListener(v -> {
                fbLangHindi = isHindi;
                applyLang.run();
            });
        }

        // Close
        Runnable dismiss = () -> {
            card.animate().scaleX(0.8f).scaleY(0.8f).alpha(0f).setDuration(200)
                .setInterpolator(new android.view.animation.AccelerateInterpolator()).start();
            scrim.animate().alpha(0f).setDuration(200)
                .withEndAction(() -> {
                    try { wm.removeView(scrim); } catch (Throwable ignored) {}
                }).start();
        };
        closeBtn.setOnClickListener(v -> dismiss.run());
        scrim.setOnClickListener(v -> dismiss.run());
        card.setOnClickListener(v -> {}); // absorb
    }

    private int dp(float v) {
        return (int) android.util.TypedValue.applyDimension(
            android.util.TypedValue.COMPLEX_UNIT_DIP, v, getResources().getDisplayMetrics());
    }

    // ── Expiry countdown ─────────────────────────────────────────────────────

    private void startCountdown() {
        mainHandler.post(new Runnable() {
            @Override public void run() {
                try {
                    SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
                    Date exp = sdf.parse(exdate());
                    if (expiryDateTv != null) {
                        SimpleDateFormat displaySdf = new SimpleDateFormat("dd MMM yyyy \u2022 hh:mm a");
                        expiryDateTv.setText("Expires " + displaySdf.format(exp));
                    }
                    long diff = exp.getTime() - System.currentTimeMillis();
                    if (diff > 0) {
                        if (tvD != null) tvD.setText(String.format("%02d", diff / 86400000L));
                        if (tvH != null) tvH.setText(String.format("%02d", (diff / 3600000L) % 24));
                        if (tvM != null) tvM.setText(String.format("%02d", (diff / 60000L) % 60));
                        if (tvS != null) tvS.setText(String.format("%02d", (diff / 1000L) % 60));
                        mainHandler.postDelayed(this, 1000);
                    } else {
                        Toast.makeText(MainActivity.this, "Subscription Expired", Toast.LENGTH_LONG).show();
                        finish();
                    }
                } catch (Exception ignored) {}
            }
        });
    }

    // ── Button state ─────────────────────────────────────────────────────────

    private void setButtonState(boolean ready) {
        if (btnAction == null) return;
        btnAction.setVisibility(View.VISIBLE);
        btnAction.setCompoundDrawablesRelativeWithIntrinsicBounds(null, null, null, null);
        if (ready) {
            if (bgmiInstalledRow != null) bgmiInstalledRow.setVisibility(View.VISIBLE);
            btnAction.setText("LAUNCH GAME");
            try { btnAction.setTypeface(androidx.core.content.res.ResourcesCompat.getFont(MainActivity.this, R.font.bold)); } catch (Throwable ignored) {}
            btnAction.setBackground(getResources().getDrawable(R.drawable.ark_btn_launch));
            btnAction.setTextColor(0xFFFFFFFF);
            btnAction.setOnClickListener(v -> {
                android.animation.ObjectAnimator sx = android.animation.ObjectAnimator.ofFloat(v, "scaleX", 1f, 1.05f, 0.98f, 1f);
                android.animation.ObjectAnimator sy = android.animation.ObjectAnimator.ofFloat(v, "scaleY", 1f, 1.05f, 0.98f, 1f);
                android.animation.AnimatorSet anim = new android.animation.AnimatorSet();
                anim.playTogether(sx, sy); anim.setDuration(260);
                anim.addListener(new android.animation.AnimatorListenerAdapter() {
                    @Override public void onAnimationEnd(android.animation.Animator a) {
                        showLicense("Launching...");
                        mainHandler.postDelayed(MainActivity.this::launchGame, DELAY);
                    }
                });
                anim.start();
            });
            // OBB already copied — show "Copied" on the side button
            if (copyObbView != null) {
                TextView obbLabel = null;
                for (int ci = 0; ci < copyObbView.getChildCount(); ci++) {
                    android.view.View ch = copyObbView.getChildAt(ci);
                    if (ch instanceof TextView) { obbLabel = (TextView) ch; break; }
                }
                if (obbLabel != null) {
                    obbLabel.setText("Copied");
                    obbLabel.setTextColor(android.graphics.Color.parseColor("#44FF88"));
                }
                copyObbView.setClickable(false);
                android.graphics.drawable.GradientDrawable copiedBg = new android.graphics.drawable.GradientDrawable();
                copiedBg.setCornerRadius(dp(28)); copiedBg.setColor(android.graphics.Color.parseColor("#0D2010"));
                copiedBg.setStroke(dp(1), android.graphics.Color.parseColor("#22664422"));
                copyObbView.setBackground(copiedBg);
            }
        } else {
            if (bgmiInstalledRow != null) bgmiInstalledRow.setVisibility(View.GONE);
            btnAction.setText("COPY GAME DATA + OBB");
            try { btnAction.setTypeface(androidx.core.content.res.ResourcesCompat.getFont(MainActivity.this, R.font.bold)); } catch (Throwable ignored) {}
            btnAction.setBackground(getResources().getDrawable(R.drawable.ark_btn_copy));
            btnAction.setTextColor(0xFFFF7A18);
            btnAction.setOnClickListener(v -> {
                android.animation.ObjectAnimator sx = android.animation.ObjectAnimator.ofFloat(v, "scaleX", 1f, 0.97f, 1.02f, 1f);
                android.animation.ObjectAnimator sy = android.animation.ObjectAnimator.ofFloat(v, "scaleY", 1f, 0.97f, 1.02f, 1f);
                android.animation.AnimatorSet anim = new android.animation.AnimatorSet();
                anim.playTogether(sx, sy); anim.setDuration(220);
                anim.addListener(new android.animation.AnimatorListenerAdapter() {
                    @Override public void onAnimationEnd(android.animation.Animator a) {
                        showDialog("Game Setup",
                            "This will copy OBB and install the game inside the loader. Keep the app open.",
                            MainActivity.this::startObbCopy, () -> {});
                    }
                });
                anim.start();
            });
        }
    }

    // ── OBB copy — Mundo Lvl10 KingCheats exact flow ─────────────────────────

    // Get Hcore virtual OBB container path
    private File getMundoObbPath() {
        // Hcore: standard Sdcard path under virtual space
        String base = android.os.Environment.getExternalStorageDirectory().getAbsolutePath() + "/Sdcard";
        return new File(base + "/Android/obb/" + PKG_BGMI);
    }

    private void startObbCopy() {
        new Thread(() -> {
            try {
                String root    = Environment.getExternalStorageDirectory().getAbsolutePath();
                File srcObbDir = new File(root + "/Android/obb/" + PKG_BGMI);

                // Step 1: get Mundo OBB container path (waits for SDK ready)
                File destDir = getMundoObbPath();
                if (!destDir.exists()) destDir.mkdirs();

                // Step 2: check already copied
                File[] existing = destDir.listFiles((d, n) -> n.endsWith(".obb"));
                if (existing != null && existing.length > 0) {
                    installIfNeeded();
                    markObbCopied();
                    runOnUiThread(() -> { showLicense("Ready"); setButtonState(true); });
                    return;
                }

                // Step 3: find source OBB (retry 3x)
                File[] srcs = null;
                for (int i = 0; i < 3; i++) {
                    srcs = srcObbDir.listFiles((d, n) -> n.endsWith(".obb"));
                    if (srcs != null && srcs.length > 0) break;
                    try { Thread.sleep(1000); } catch (InterruptedException ignored) {}
                }
                if (srcs == null || srcs.length == 0) {
                    runOnUiThread(() -> showDialog("OBB Not Found",
                        "Install BGMI first, then retry.", () -> {}, () -> {}));
                    return;
                }

                File src   = srcs[0];
                File dst   = new File(destDir, src.getName());
                long total = src.length();
                AtomicBoolean done = new AtomicBoolean(false);

                // 5 min timeout
                mainHandler.postDelayed(() -> {
                    if (!done.get()) { done.set(true); runOnUiThread(() -> showLicense("Copy timed out")); }
                }, 300_000);

                // Step 4: copy with 512KB buffer
                try (InputStream  in  = new FileInputStream(src);
                     OutputStream out = new FileOutputStream(dst)) {
                    byte[] buf = new byte[512 * 1024];
                    long copied = 0L; int n;
                    while ((n = in.read(buf)) != -1) {
                        out.write(buf, 0, n); copied += n;
                        int pct = total > 0 ? (int)((copied * 100L) / total) : 0;
                        final long c2 = copied;
                        runOnUiThread(() -> showObbCopy("Copying OBB...", pct, c2, total));
                    }
                    out.flush();
                }

                if (done.get()) return;
                done.set(true);

                // Step 5: mark copied BEFORE install
                markObbCopied();

                // Step 6: install APK inside Mundo virtual space
                runOnUiThread(() -> showObbCopy("Installing APK...", 100, total, total));
                installIfNeeded();

                runOnUiThread(() -> { showLicense("Ready"); setButtonState(true); });

            } catch (Exception e) {
                runOnUiThread(() -> showLicense("Copy failed: " + e.getMessage()));
            }
        }).start();
    }

    private void installIfNeeded() {
        try {
            if (MundoCore.get() != null && !MundoCore.get().isInstalled(PKG_BGMI, 0)) {
                MundoCore.get().installPackageAsUser(PKG_BGMI, 0);
            }
        } catch (Throwable t) {
            try { MundoCore.get().installPackageAsUser(PKG_BGMI, 0); }
            catch (Throwable ignored) {}
        }
    }

    private void markObbCopied() {
        new Prefs(this).setBool(KEY_OBB_DONE, true);
    }

    // ── Game launch ───────────────────────────────────────────────────────────

    private void launchGame() {
        new Thread(() -> {
            try {
                if (MundoCore.get() != null && !MundoCore.get().isInstalled(PKG_BGMI, 0)) {
                    runOnUiThread(() -> showLicense("Installing BGMI..."));
                    installIfNeeded();
                }
                ArkCrashLogger.breadcrumb("launch", "launchApk BGMI start");
            try { MundoCore.get().launchApk(PKG_BGMI, 0); }
            catch (Throwable _lt) { ArkCrashLogger.launchCrash("launchApk", _lt); throw _lt instanceof RuntimeException ? (RuntimeException)_lt : new RuntimeException(_lt); }
                // Start floating overlay menu (ArkCheat TCP feature control)
                runOnUiThread(this::startOverlayMenu);
            } catch (Exception e) {
                runOnUiThread(() -> Toast.makeText(this,
                    "Launch failed: " + e.getMessage(), Toast.LENGTH_SHORT).show());
            }
        }).start();
    }

    // ── Floating overlay menu — UNCHANGED from original ───────────────────────

    private void startOverlayMenu() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M && !Settings.canDrawOverlays(this)) {
            try {
                Intent i = new Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION,
                        Uri.parse("package:" + getPackageName()));
                i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                startActivity(i);
            } catch (Exception ignored) {}
            Toast.makeText(this, "Enable overlay, then relaunch", Toast.LENGTH_LONG).show();
            return;
        }
        try {
            startService(new Intent(this, OverlayService.class));
        } catch (Exception e) {
            Toast.makeText(this, "Overlay start failed: " + e.getMessage(), Toast.LENGTH_SHORT).show();
        }
    }

    // ── UI helpers ────────────────────────────────────────────────────────────

    private void showLicense(String status) {
        runOnUiThread(() -> {
            if (licenseLayout    != null) licenseLayout.setVisibility(View.VISIBLE);
            if (processingLayout != null) processingLayout.setVisibility(View.GONE);
            if (statusText       != null) statusText.setText(status);
        });
    }

    private void showObbCopy(String label, int pct, long done, long total) {
        runOnUiThread(() -> {
            if (licenseLayout    != null) licenseLayout.setVisibility(View.GONE);
            if (processingLayout != null) processingLayout.setVisibility(View.VISIBLE);
            if (statusText       != null) statusText.setText(label);
            if (syncText         != null) syncText.setText("Copying game data...");
            if (obbProgressBar   != null) obbProgressBar.setProgress(pct);
            if (obbPercentText   != null) obbPercentText.setText(pct + "%");
            if (obbSizeText != null && total > 0)
                obbSizeText.setText(fmt(done) + " / " + fmt(total));
        });
    }

    private void showDialog(String title, String msg, Runnable ok, Runnable cancel) {
        runOnUiThread(() -> {
            if (isFinishing() || isDestroyed()) return;
            if (bsd != null && bsd.isShowing()) bsd.dismiss();
            bsd = new BottomSheetDialog(this, R.style.AppTheme);
            View v = getLayoutInflater().inflate(R.layout.bottom_sheet_dialog_layout, null);
            bsd.setContentView(v);
            ImageView    ico = v.findViewById(R.id.dialog_icon);
            TextView     tv1 = v.findViewById(R.id.title);
            TextView     tv2 = v.findViewById(R.id.msg);
            AppCompatButton okB = v.findViewById(R.id.btn);
            AppCompatButton cxB = v.findViewById(R.id.btn_cancle);
            if (ico != null) ico.setImageDrawable(getResources().getDrawable(R.drawable.ark_logo));
            if (tv1 != null) tv1.setText(title);
            if (tv2 != null) tv2.setText(msg);
            if (okB != null) okB.setOnClickListener(x -> { bsd.dismiss(); ok.run(); });
            if (cxB != null) cxB.setOnClickListener(x -> { bsd.dismiss(); cancel.run(); });
            bsd.show();
        });
    }

    private static String fmt(long b) {
        if (b <= 0) return "0 B";
        if (b < 1048576) return String.format("%.1f KB", b / 1024.0);
        return String.format("%.1f MB", b / 1048576.0);
    }

    private void setAppNameFont() { /* replaced by programmatic UI */ }

    @Override
    public void onBackPressed() {
        Toast.makeText(this, "Press back twice to exit", Toast.LENGTH_SHORT).show();
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        mainHandler.removeCallbacksAndMessages(null);
        if (bsd != null && bsd.isShowing()) bsd.dismiss();
    }
}
