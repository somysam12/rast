﻿#include <jni.h>
#include <string>
#include <vector>
#include <android/log.h>
#include <android/asset_manager.h>
#include <android/asset_manager_jni.h>
#include <curl/curl.h>
#include <openssl/evp.h>
#include <openssl/hmac.h>
#include <openssl/rand.h>
#include <openssl/sha.h>
#include <openssl/md5.h>
#include <json.hpp>
#include "oxorany.h"
#include <unistd.h>
#include <cstring>
#include <cstdio>
#include <cstdlib>
#include "decrypt.h"

#define LOG_TAG "KC"
#define LOGE(...) __android_log_print(ANDROID_LOG_ERROR, LOG_TAG, __VA_ARGS__)

using json = nlohmann::ordered_json;

// ═══════════════════════════════════════════════════════════════════════
//  PANEL CONFIG — split-string so URL never appears in .so
// ═══════════════════════════════════════════════════════════════════════
static std::string getPanelBase() {
    std::string p1(oxorany("https://"));
    std::string p2(oxorany("arkcheat."));
    std::string p3(oxorany("battleground-"));
    std::string p4(oxorany("hub."));
    std::string p5(oxorany("shop"));
    return p1 + p2 + p3 + p4 + p5;
}

#define EP_VALIDBOOL  oxorany("/validbool")
#define EP_HEARTBEAT  oxorany("/p/sw.js")
#define EP_APK_KILL   oxorany("/server/apk_kill.php")
#define EP_LIB_VER    oxorany("/server/lib_version.php")
#define EP_LIB_UNLOCK oxorany("/secure/unlock")
#define EP_LIB_DL     oxorany("/secure/lib")

// ═══════════════════════════════════════════════════════════════════════
//  SECRETS — must match secrets.php on panel
// ═══════════════════════════════════════════════════════════════════════
#define _AES_KEY_HEX  oxorany("5c3d9f2a8b1e4c6079d2f3a4b5c6e7f8091a2b3c4d5e6f708192a3b4c5d6e7f8")
#define _HMAC_KEY     oxorany("X9kL2mQ7vR4nB1eY3pT8wS5uJ6dA0cF")
static const uint64_t _XKEY1 = 0xB7E15163ULL;
static const uint64_t _XKEY2 = 0x9E3779B9ULL;

// ═══════════════════════════════════════════════════════════════════════
//  GLOBALS
// ═══════════════════════════════════════════════════════════════════════
static std::string g_exdate   = "NULL";
static std::string g_userKey;
static std::string g_serial;
static std::string g_pkgName;
static char        g_enc[64]  = {};
static bool        g_loginOk  = false;
static std::string g_loginToken;
static std::string g_caPath;
static std::string g_licKey;   // key from ArkCheatJava.lic

// Read license key from /storage/emulated/0/Android/ArkCheatJava.lic
static std::string readLicKey() {
    FILE* f = fopen("/storage/emulated/0/Android/ArkCheatJava.lic", "r");
    if (!f) return "";
    char buf[512]; std::string key;
    while (fgets(buf, sizeof(buf), f)) {
        std::string line(buf);
        if (line.size() > 4 && line.substr(0,4) == "KEY=") {
            key = line.substr(4);
            while (!key.empty() && (key.back()=='\n'||key.back()=='\r'||key.back()==' '))
                key.pop_back();
            break;
        }
    }
    fclose(f); return key;
}

JNIEXPORT jint JNI_OnLoad(JavaVM* vm, void*) {
    curl_global_init(CURL_GLOBAL_ALL);
    g_licKey = readLicKey();
    return JNI_VERSION_1_6;
}

// APK signature (SHA-256 of signing cert) — replace with your keystore hash
#define EXPECTED_SIGNATURE oxorany("77f05d53ce8bf1855caef38ce87f13a8bb2b1b2cdd2d48da9d3ba897eac4549e")

// ═══════════════════════════════════════════════════════════════════════
//  HELPERS
// ═══════════════════════════════════════════════════════════════════════
struct MemBuf { char* data; size_t len; };

static size_t curlWrite(void* p, size_t sz, size_t n, void* ud) {
    size_t total = sz * n;
    auto* m = (MemBuf*)ud;
    m->data = (char*)realloc(m->data, m->len + total + 1);
    if (!m->data) return 0;
    memcpy(m->data + m->len, p, total);
    m->len += total;
    m->data[m->len] = 0;
    return total;
}

static void hexEncode(const unsigned char* in, int len, char* out) {
    for (int i = 0; i < len; i++) sprintf(out + i*2, "%02x", in[i]);
    out[len*2] = 0;
}
static void hexDecode(const char* hex, unsigned char* out, int outLen) {
    for (int i = 0; i < outLen; i++) {
        unsigned int v = 0; sscanf(hex + i*2, "%02x", &v); out[i] = (unsigned char)v;
    }
}

// ── CA cert from APK assets ──────────────────────────────────────────
static std::string extractCACert(JNIEnv* env, jobject context) {
    if (!g_caPath.empty()) {
        FILE* f = fopen(g_caPath.c_str(), "r");
        if (f) { fclose(f); return g_caPath; }
    }
    jclass ctxCls = env->GetObjectClass(context);
    jmethodID gfd = env->GetMethodID(ctxCls, "getFilesDir", "()Ljava/io/File;");
    jobject fd = env->CallObjectMethod(context, gfd);
    jclass fc = env->GetObjectClass(fd);
    jmethodID gp = env->GetMethodID(fc, "getAbsolutePath", "()Ljava/lang/String;");
    jstring ps = (jstring)env->CallObjectMethod(fd, gp);
    const char* pc = env->GetStringUTFChars(ps, nullptr);
    std::string dest = std::string(pc) + oxorany("/.cacert.pem");
    env->ReleaseStringUTFChars(ps, pc);
    FILE* chk = fopen(dest.c_str(), "r");
    if (chk) { fclose(chk); g_caPath = dest; return dest; }
    jmethodID ga = env->GetMethodID(ctxCls, "getAssets", "()Landroid/content/res/AssetManager;");
    jobject am = env->CallObjectMethod(context, ga);
    AAssetManager* mgr = AAssetManager_fromJava(env, am);
    AAsset* asset = AAssetManager_open(mgr, oxorany("cacert.pem"), AASSET_MODE_STREAMING);
    if (!asset) { LOGE("CA cert not found in assets"); return ""; }
    FILE* out = fopen(dest.c_str(), "wb");
    if (!out) { AAsset_close(asset); return ""; }
    char buf[4096]; int nb;
    while ((nb = AAsset_read(asset, buf, sizeof(buf))) > 0) fwrite(buf, 1, nb, out);
    fclose(out); AAsset_close(asset);
    g_caPath = dest; return dest;
}

// ── Base64url ────────────────────────────────────────────────────────
static const char B64[] = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789-_";
static std::string b64url_encode(const unsigned char* data, size_t len) {
    std::string out; out.reserve((len*4/3)+4);
    for (size_t i = 0; i < len; i += 3) {
        uint32_t n = ((uint32_t)data[i]) << 16;
        if (i+1 < len) n |= ((uint32_t)data[i+1]) << 8;
        if (i+2 < len) n |= data[i+2];
        out += B64[(n >> 18) & 0x3F]; out += B64[(n >> 12) & 0x3F];
        if (i+1 < len) out += B64[(n >> 6) & 0x3F];
        if (i+2 < len) out += B64[n & 0x3F];
    }
    return out;
}
static int b64url_decodeByte(char c) {
    if (c >= 'A' && c <= 'Z') return c-'A';
    if (c >= 'a' && c <= 'z') return c-'a'+26;
    if (c >= '0' && c <= '9') return c-'0'+52;
    if (c == '-') return 62; if (c == '_') return 63; return -1;
}
static std::string b64url_decode(const std::string& s) {
    std::string out;
    for (size_t i = 0; i < s.size(); i += 4) {
        int a = b64url_decodeByte(s[i]);
        int b = (i+1<s.size()) ? b64url_decodeByte(s[i+1]) : -1;
        int c = (i+2<s.size()) ? b64url_decodeByte(s[i+2]) : -1;
        int d = (i+3<s.size()) ? b64url_decodeByte(s[i+3]) : -1;
        if (a<0||b<0) break;
        out += (char)((a<<2)|(b>>4));
        if (c>=0) out += (char)(((b&0xF)<<4)|(c>>2));
        if (d>=0) out += (char)(((c&0x3)<<6)|d);
    }
    return out;
}

// ── AES-256-GCM encrypt ──────────────────────────────────────────────
static std::string aes_gcm_encrypt(const std::string& plain) {
    unsigned char key[32]; hexDecode(_AES_KEY_HEX, key, 32);
    unsigned char nonce[12]; RAND_bytes(nonce, 12);
    EVP_CIPHER_CTX* ctx = EVP_CIPHER_CTX_new();
    EVP_EncryptInit_ex(ctx, EVP_aes_256_gcm(), nullptr, nullptr, nullptr);
    EVP_CIPHER_CTX_ctrl(ctx, EVP_CTRL_GCM_SET_IVLEN, 12, nullptr);
    EVP_EncryptInit_ex(ctx, nullptr, nullptr, key, nonce);
    int outLen = 0;
    std::vector<unsigned char> ct(plain.size()+16);
    EVP_EncryptUpdate(ctx, ct.data(), &outLen, (unsigned char*)plain.c_str(), plain.size());
    int totalLen = outLen;
    EVP_EncryptFinal_ex(ctx, ct.data()+totalLen, &outLen); totalLen += outLen;
    unsigned char tag[16];
    EVP_CIPHER_CTX_ctrl(ctx, EVP_CTRL_GCM_GET_TAG, 16, tag);
    EVP_CIPHER_CTX_free(ctx);
    std::vector<unsigned char> out(12+16+totalLen);
    memcpy(out.data(), nonce, 12); memcpy(out.data()+12, tag, 16);
    memcpy(out.data()+28, ct.data(), totalLen);
    memset(key, 0, 32);
    return b64url_encode(out.data(), out.size());
}

// ── AES-256-GCM decrypt ──────────────────────────────────────────────
static std::string aes_gcm_decrypt(const std::string& b64) {
    std::string raw = b64url_decode(b64);
    if (raw.size() < 29) return "";
    unsigned char key[32]; hexDecode(_AES_KEY_HEX, key, 32);
    const unsigned char* nonce = (unsigned char*)raw.data();
    const unsigned char* tag   = (unsigned char*)raw.data()+12;
    const unsigned char* ct    = (unsigned char*)raw.data()+28;
    int ctLen = raw.size()-28;
    EVP_CIPHER_CTX* ctx = EVP_CIPHER_CTX_new();
    EVP_DecryptInit_ex(ctx, EVP_aes_256_gcm(), nullptr, nullptr, nullptr);
    EVP_CIPHER_CTX_ctrl(ctx, EVP_CTRL_GCM_SET_IVLEN, 12, nullptr);
    EVP_DecryptInit_ex(ctx, nullptr, nullptr, key, nonce);
    int outLen = 0;
    std::vector<unsigned char> plain(ctLen+16);
    EVP_DecryptUpdate(ctx, plain.data(), &outLen, ct, ctLen);
    int totalLen = outLen;
    EVP_CIPHER_CTX_ctrl(ctx, EVP_CTRL_GCM_SET_TAG, 16, (void*)tag);
    int ok = EVP_DecryptFinal_ex(ctx, plain.data()+totalLen, &outLen);
    totalLen += outLen; EVP_CIPHER_CTX_free(ctx);
    memset(key, 0, 32);
    if (ok <= 0) return "";
    return std::string((char*)plain.data(), totalLen);
}

// ── HMAC-SHA256 ──────────────────────────────────────────────────────
static std::string hmac_sha256(const std::string& data) {
    unsigned char hash[32]; unsigned int hashLen = 0;
    HMAC(EVP_sha256(), _HMAC_KEY, strlen(_HMAC_KEY),
         (unsigned char*)data.c_str(), data.size(), hash, &hashLen);
    char hex[65]; hexEncode(hash, 32, hex);
    return std::string(hex);
}

static std::string generateLoginToken() {
    unsigned char bytes[32]; RAND_bytes(bytes, 32);
    char hex[65]; hexEncode(bytes, 32, hex);
    return std::string(hex);
}

// ── Device info ──────────────────────────────────────────────────────
static std::string getAndroidId(JNIEnv* env, jobject ctx) {
    jclass cc = env->FindClass("android/content/Context");
    jmethodID getCR = env->GetMethodID(cc, "getContentResolver", "()Landroid/content/ContentResolver;");
    jobject cr = env->CallObjectMethod(ctx, getCR);
    jclass sc = env->FindClass("android/provider/Settings$Secure");
    jmethodID gs = env->GetStaticMethodID(sc, "getString", "(Landroid/content/ContentResolver;Ljava/lang/String;)Ljava/lang/String;");
    auto s = (jstring)env->CallStaticObjectMethod(sc, gs, cr, env->NewStringUTF("android_id"));
    if (!s) return "";
    const char* c = env->GetStringUTFChars(s, nullptr);
    std::string r(c); env->ReleaseStringUTFChars(s, c); return r;
}
static std::string getModel(JNIEnv* env) {
    jclass bc = env->FindClass("android/os/Build");
    jfieldID f = env->GetStaticFieldID(bc, "MODEL", "Ljava/lang/String;");
    auto s = (jstring)env->GetStaticObjectField(bc, f);
    const char* c = env->GetStringUTFChars(s, nullptr);
    std::string r(c); env->ReleaseStringUTFChars(s, c); return r;
}
static std::string getBrand(JNIEnv* env) {
    jclass bc = env->FindClass("android/os/Build");
    jfieldID f = env->GetStaticFieldID(bc, "BRAND", "Ljava/lang/String;");
    auto s = (jstring)env->GetStaticObjectField(bc, f);
    const char* c = env->GetStringUTFChars(s, nullptr);
    std::string r(c); env->ReleaseStringUTFChars(s, c); return r;
}
static std::string getPkg(JNIEnv* env, jobject ctx) {
    jclass cc = env->FindClass("android/content/Context");
    jmethodID m = env->GetMethodID(cc, "getPackageName", "()Ljava/lang/String;");
    auto s = (jstring)env->CallObjectMethod(ctx, m);
    const char* c = env->GetStringUTFChars(s, nullptr);
    std::string r(c); env->ReleaseStringUTFChars(s, c); return r;
}
static std::string makeUUID(JNIEnv* env, const std::string& input) {
    jclass uc = env->FindClass("java/util/UUID");
    jmethodID fb = env->GetStaticMethodID(uc, "nameUUIDFromBytes", "([B)Ljava/util/UUID;");
    jmethodID ts = env->GetMethodID(uc, "toString", "()Ljava/lang/String;");
    jbyteArray ba = env->NewByteArray(input.size());
    env->SetByteArrayRegion(ba, 0, input.size(), (jbyte*)input.c_str());
    jobject uuid = env->CallStaticObjectMethod(uc, fb, ba);
    auto s = (jstring)env->CallObjectMethod(uuid, ts);
    const char* c = env->GetStringUTFChars(s, nullptr);
    std::string r(c); env->ReleaseStringUTFChars(s, c); return r;
}

// ═══════════════════════════════════════════════════════════════════════
//  JNI EXPORTS — MainActivity
// ═══════════════════════════════════════════════════════════════════════
extern "C" JNIEXPORT jstring JNICALL
Java_com_bgmi_MainActivity_exdate(JNIEnv* env, jclass) {
    return env->NewStringUTF(g_exdate.c_str());
}
extern "C" JNIEXPORT jstring JNICALL
Java_com_bgmi_MainActivity_ZENINOP(JNIEnv* env, jobject) {
    return env->NewStringUTF(g_enc);
}

// ═══════════════════════════════════════════════════════════════════════
//  JNI EXPORTS — LoginActivity
// ═══════════════════════════════════════════════════════════════════════
extern "C" JNIEXPORT jstring JNICALL
Java_com_bgmi_LoginActivity_GetKey(JNIEnv* env, jobject) {
    return env->NewStringUTF(oxorany("https://t.me/"));
}

extern "C" JNIEXPORT jboolean JNICALL
Java_com_bgmi_LoginActivity_nativeVerifySignature(JNIEnv* env, jobject, jobject context) {
    jclass contextClass = env->GetObjectClass(context);
    jmethodID midGetPM = env->GetMethodID(contextClass, "getPackageManager", "()Landroid/content/pm/PackageManager;");
    jobject pm = env->CallObjectMethod(context, midGetPM);
    jmethodID midGetPkg = env->GetMethodID(contextClass, "getPackageName", "()Ljava/lang/String;");
    jstring pkgName = (jstring)env->CallObjectMethod(context, midGetPkg);
    jclass pmClass = env->GetObjectClass(pm);
    jmethodID midGetInfo = env->GetMethodID(pmClass, "getPackageInfo", "(Ljava/lang/String;I)Landroid/content/pm/PackageInfo;");
    jobject pkgInfo = env->CallObjectMethod(pm, midGetInfo, pkgName, 64);
    jclass piCls = env->GetObjectClass(pkgInfo);
    jfieldID fidSig = env->GetFieldID(piCls, "signatures", "[Landroid/content/pm/Signature;");
    jobjectArray sigs = (jobjectArray)env->GetObjectField(pkgInfo, fidSig);
    if (!sigs) return JNI_FALSE;
    jsize cnt = env->GetArrayLength(sigs);
    for (jsize i = 0; i < cnt; i++) {
        jobject sig = env->GetObjectArrayElement(sigs, i);
        jclass sc = env->GetObjectClass(sig);
        jmethodID tb = env->GetMethodID(sc, "toByteArray", "()[B");
        jbyteArray bytes = (jbyteArray)env->CallObjectMethod(sig, tb);
        jsize len = env->GetArrayLength(bytes);
        jbyte* buf = env->GetByteArrayElements(bytes, nullptr);
        unsigned char hash[SHA256_DIGEST_LENGTH];
        SHA256((unsigned char*)buf, len, hash);
        env->ReleaseByteArrayElements(bytes, buf, 0);
        char hex[65]; hexEncode(hash, SHA256_DIGEST_LENGTH, hex);
        if (strcasecmp(hex, EXPECTED_SIGNATURE) == 0) return JNI_TRUE;
    }
    return JNI_FALSE;
}

// ═══════════════════════════════════════════════════════════════════════
//  JNI EXPORTS — Downtwo (lib download URLs)
// ═══════════════════════════════════════════════════════════════════════
extern "C" JNIEXPORT jstring JNICALL
Java_com_bgmi_utils_Downtwo_Version(JNIEnv* env, jclass) {
    std::string url = getPanelBase() + std::string(EP_LIB_VER);
    return env->NewStringUTF(url.c_str());
}
extern "C" JNIEXPORT jstring JNICALL
Java_com_bgmi_utils_Downtwo_Link(JNIEnv* env, jclass) {
    std::string url = getPanelBase() + std::string(EP_LIB_DL);
    return env->NewStringUTF(url.c_str());
}
extern "C" JNIEXPORT jstring JNICALL
Java_com_bgmi_utils_Downtwo_UnlockUrl(JNIEnv* env, jclass) {
    std::string url = getPanelBase() + std::string(EP_LIB_UNLOCK);
    return env->NewStringUTF(url.c_str());
}
extern "C" JNIEXPORT jstring JNICALL
Java_com_bgmi_utils_Downtwo_AesKey(JNIEnv* env, jclass) {
    return env->NewStringUTF(_AES_KEY_HEX);
}
extern "C" JNIEXPORT jstring JNICALL
Java_com_bgmi_utils_Downtwo_HmacKey(JNIEnv* env, jclass) {
    return env->NewStringUTF(_HMAC_KEY);
}

// ═══════════════════════════════════════════════════════════════════════
//  JNI EXPORTS — ArkApplication SDK key
// ═══════════════════════════════════════════════════════════════════════
extern "C" JNIEXPORT jstring JNICALL
Java_com_bgmi_ArkApplication_getSdkKey(JNIEnv* env, jclass) {
    return env->NewStringUTF(oxorany("HCORE"));
}

// ═══════════════════════════════════════════════════════════════════════
//  JNI EXPORTS — HeartbeatManager (secrets from native)
// ═══════════════════════════════════════════════════════════════════════
extern "C" JNIEXPORT jstring JNICALL
Java_com_bgmi_HeartbeatManager_hbUrl(JNIEnv* env, jclass) {
    std::string url = getPanelBase() + std::string(EP_HEARTBEAT);
    return env->NewStringUTF(url.c_str());
}
extern "C" JNIEXPORT jstring JNICALL
Java_com_bgmi_HeartbeatManager_hbAesKey(JNIEnv* env, jclass) {
    return env->NewStringUTF(_AES_KEY_HEX);
}
extern "C" JNIEXPORT jstring JNICALL
Java_com_bgmi_HeartbeatManager_hbHmacKey(JNIEnv* env, jclass) {
    return env->NewStringUTF(_HMAC_KEY);
}
extern "C" JNIEXPORT jlong JNICALL
Java_com_bgmi_HeartbeatManager_hbXkey1(JNIEnv*, jclass) {
    return (jlong)_XKEY1;
}

// ═══════════════════════════════════════════════════════════════════════
//  JNI EXPORTS — IntegrityGuard
// ═══════════════════════════════════════════════════════════════════════
extern "C" JNIEXPORT jstring JNICALL
Java_com_bgmi_utils_IntegrityGuard_expectedSigHash(JNIEnv* env, jclass) {
    return env->NewStringUTF(EXPECTED_SIGNATURE);
}

// ═══════════════════════════════════════════════════════════════════════
//  JNI EXPORTS — APK kill URL
// ═══════════════════════════════════════════════════════════════════════
extern "C" JNIEXPORT jstring JNICALL
Java_com_bgmi_LoginActivity_nativeApkKillUrl(JNIEnv* env, jclass) {
    std::string url = getPanelBase() + std::string(EP_APK_KILL);
    return env->NewStringUTF(url.c_str());
}
extern "C" JNIEXPORT jstring JNICALL
Java_com_bgmi_LoginActivity_nativeApkDownloadUrl(JNIEnv* env, jclass) {
    std::string url = getPanelBase() + oxorany("/uploads/apk/");
    return env->NewStringUTF(url.c_str());
}

// ═══════════════════════════════════════════════════════════════════════
//  LOGIN — AES-256-GCM + HMAC protocol (/validbool)
//  bValid is NEVER set to true locally — server decides via q==7
// ═══════════════════════════════════════════════════════════════════════
extern "C" JNIEXPORT jstring JNICALL
Java_com_bgmi_LoginActivity_Check(JNIEnv* env, jclass, jobject mContext, jstring mUserKey) {
    const char* keyC = env->GetStringUTFChars(mUserKey, nullptr);
    std::string userKey(keyC);
    env->ReleaseStringUTFChars(mUserKey, keyC);

    std::string hwid = userKey + getAndroidId(env, mContext) + getModel(env) + getBrand(env);
    std::string serial = makeUUID(env, hwid);
    std::string pkg = getPkg(env, mContext);
    std::string errMsg;

    g_loginOk = false;

    std::string caPath = extractCACert(env, mContext);

    for (int attempt = 0; attempt < 3; attempt++) {
        json payload;
        payload["k"]   = userKey;
        payload["d"]   = serial;
        payload["t"]   = (long)time(nullptr);
        payload["pkg"] = pkg;
        std::string plainJson = payload.dump();

        std::string p1 = aes_gcm_encrypt(plainJson);
        if (p1.empty()) { errMsg = "Encryption failed"; continue; }
        std::string p2 = hmac_sha256(p1);

        std::string url = getPanelBase() + std::string(EP_VALIDBOOL);
        std::string postData = "p1=" + p1 + "&p2=" + p2;

        CURL* curl = curl_easy_init();
        std::string body;
        if (curl) {
            MemBuf mem = {nullptr, 0};
            curl_easy_setopt(curl, CURLOPT_URL, url.c_str());
            curl_easy_setopt(curl, CURLOPT_POSTFIELDS, postData.c_str());
            curl_easy_setopt(curl, CURLOPT_WRITEFUNCTION, curlWrite);
            curl_easy_setopt(curl, CURLOPT_WRITEDATA, &mem);
            curl_easy_setopt(curl, CURLOPT_TIMEOUT, 20L);
            curl_easy_setopt(curl, CURLOPT_CONNECTTIMEOUT, 15L);
            curl_easy_setopt(curl, CURLOPT_NOSIGNAL, 1L);
            if (!caPath.empty())
                curl_easy_setopt(curl, CURLOPT_CAINFO, caPath.c_str());
            CURLcode cres = curl_easy_perform(curl);
            long httpCode = 0;
            curl_easy_getinfo(curl, CURLINFO_RESPONSE_CODE, &httpCode);
            curl_easy_cleanup(curl);
            if (cres == CURLE_OK && httpCode == 200 && mem.data)
                body = std::string(mem.data, mem.len);
            else if (cres != CURLE_OK)
                LOGE("CHECK curl error: %s", curl_easy_strerror(cres));
            free(mem.data);
        }

        if (body.empty()) {
            errMsg = "Server not responding";
            if (attempt < 2) { usleep(800000); continue; }
            break;
        }

        // Fake-server detection
        if (body.rfind("/*", 0) == 0) { errMsg = "Authentication failed"; break; }

        size_t dot = body.rfind('.');
        if (dot == std::string::npos) {
            errMsg = "Invalid server response";
            if (attempt < 2) { usleep(800000); continue; }
            break;
        }

        std::string encBody = body.substr(0, dot);
        std::string sigHex  = body.substr(dot + 1);

        // HMAC verify — fake server cannot forge this
        if (hmac_sha256(encBody) != sigHex) {
            errMsg = "Server signature mismatch";
            LOGE("HMAC mismatch");
            break;
        }

        // AES decrypt — fake server cannot decrypt without key
        std::string plainResp = aes_gcm_decrypt(encBody);
        if (plainResp.empty()) {
            errMsg = "Response decryption failed";
            if (attempt < 2) { usleep(800000); continue; }
            break;
        }

        try {
            json jr = json::parse(plainResp);
            int q = jr.value("q", 0);

            if (q == 7) {
                long long xRaw = jr.value("x", (long long)0);
                long long expUnix = xRaw ^ (long long)_XKEY1;
                if (expUnix > 0) {
                    time_t et = (time_t)expUnix;
                    struct tm tm_buf; char dateBuf[32] = {};
                    if (localtime_r(&et, &tm_buf))
                        strftime(dateBuf, sizeof(dateBuf), "%Y-%m-%d %H:%M:%S", &tm_buf);
                    g_exdate = dateBuf;
                } else {
                    g_exdate = "2099-12-31 23:59:59";
                }
                g_userKey = userKey; g_serial = serial; g_pkgName = pkg;
                g_loginOk = true;
                break;
            } else if (q == 1) { errMsg = "Server under maintenance"; break; }
            else if (q == 2)   { errMsg = "Key has expired"; break; }
            else if (q == 3)   { errMsg = "Max device limit reached"; break; }
            else if (q == 4)   { errMsg = "Key is invalid"; break; }
            else if (q == 5)   { errMsg = "Key is bound to a different app"; break; }
            else if (q == 6)   { errMsg = "Key has been blocked"; break; }
            else               { errMsg = "Key is invalid or expired"; break; }
        } catch (...) {
            errMsg = "Invalid server response";
            if (attempt < 2) { usleep(800000); continue; }
            break;
        }
        break;
    }

    if (g_loginOk) {
        g_loginToken = generateLoginToken();
        g_licKey = g_userKey;   // key confirmed valid — also cached for native use
        // Return the actual token (Mundo flow) — Java verifies it via nativeVerifyLoginToken.
        return env->NewStringUTF(g_loginToken.c_str());
    }
    return env->NewStringUTF(errMsg.c_str());
}

// Login token verify (anti-smali-patch)
extern "C" JNIEXPORT jboolean JNICALL
Java_com_bgmi_LoginActivity_nativeVerifyLoginToken(JNIEnv* env, jclass, jstring token) {
    if (!g_loginOk || g_loginToken.empty() || !token) return JNI_FALSE;
    const char* c = env->GetStringUTFChars(token, nullptr);
    std::string t(c); env->ReleaseStringUTFChars(token, c);
    bool match = (t == g_loginToken);
    if (match) g_loginToken.clear();
    return match ? JNI_TRUE : JNI_FALSE;
}

extern "C" JNIEXPORT jstring JNICALL
Java_com_bgmi_LoginActivity_nativeGetSerial(JNIEnv* env, jclass) {
    return env->NewStringUTF(g_serial.c_str());
}

// ═══════════════════════════════════════════════════════════════════════
//  NATIVE HEARTBEAT — AES+HMAC (/p/sw.js) — unhookable from Java
// ═══════════════════════════════════════════════════════════════════════
extern "C" JNIEXPORT jint JNICALL
Java_com_bgmi_HeartbeatManager_nativeBeat(JNIEnv* env, jclass,
    jstring jKey, jstring jSerial, jstring jPkg) {
    if (!jKey || !jSerial || !jPkg) return -1;
    const char* keyC = env->GetStringUTFChars(jKey, nullptr);
    const char* serC = env->GetStringUTFChars(jSerial, nullptr);
    const char* pkgC = env->GetStringUTFChars(jPkg, nullptr);
    json payload;
    payload["k"] = std::string(keyC); payload["d"] = std::string(serC);
    payload["t"] = (long)time(nullptr); payload["pkg"] = std::string(pkgC);
    env->ReleaseStringUTFChars(jKey, keyC);
    env->ReleaseStringUTFChars(jSerial, serC);
    env->ReleaseStringUTFChars(jPkg, pkgC);
    std::string p1 = aes_gcm_encrypt(payload.dump());
    if (p1.empty()) return -1;
    std::string p2 = hmac_sha256(p1);
    std::string url = getPanelBase() + std::string(EP_HEARTBEAT);
    std::string postData = "p1=" + p1 + "&p2=" + p2;
    CURL* curl = curl_easy_init();
    if (!curl) return -1;
    MemBuf mem = {nullptr, 0};
    curl_easy_setopt(curl, CURLOPT_URL, url.c_str());
    curl_easy_setopt(curl, CURLOPT_POSTFIELDS, postData.c_str());
    curl_easy_setopt(curl, CURLOPT_WRITEFUNCTION, curlWrite);
    curl_easy_setopt(curl, CURLOPT_WRITEDATA, &mem);
    curl_easy_setopt(curl, CURLOPT_TIMEOUT, 15L);
    curl_easy_setopt(curl, CURLOPT_CONNECTTIMEOUT, 15L);
    if (!g_caPath.empty()) curl_easy_setopt(curl, CURLOPT_CAINFO, g_caPath.c_str());
    CURLcode cres = curl_easy_perform(curl);
    long httpCode = 0;
    curl_easy_getinfo(curl, CURLINFO_RESPONSE_CODE, &httpCode);
    curl_easy_cleanup(curl);
    std::string body;
    if (cres == CURLE_OK && httpCode == 200 && mem.data)
        body = std::string(mem.data, mem.len);
    free(mem.data);
    if (body.empty() || body.rfind("/*", 0) == 0) return -1;
    size_t dot = body.rfind('.');
    if (dot == std::string::npos) return -1;
    std::string encBody = body.substr(0, dot);
    std::string sigHex  = body.substr(dot + 1);
    if (hmac_sha256(encBody) != sigHex) return -1;
    std::string plain = aes_gcm_decrypt(encBody);
    if (plain.empty()) return -1;
    try { json j = json::parse(plain); return j.value("q", -1); }
    catch (...) { return -1; }
}
