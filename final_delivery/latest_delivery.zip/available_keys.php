<?php
// This file is now redirected to licence_key_list.php which has been updated with the correct UI and table names
header("Location: licence_key_list.php");
exit;
?>