<?php
// Redirect to transactions page (balance page deprecated)
header('Location: user_transactions.php');
exit();
?>
